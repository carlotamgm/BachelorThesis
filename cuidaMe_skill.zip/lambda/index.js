/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
 
const Alexa = require('ask-sdk-core');
const request = require('sync-request');
const axios = require("axios");
const moment = require('moment-timezone');

// Import all interfaces
const { Bienvenida } = require('./interfaces/bienvenida.js');
const { Avatar } = require('./interfaces/avatares.js');
const { HomePage } = require('./interfaces/home.js');
const { MisTareas } = require('./interfaces/misTareas.js');
const { Tarea } = require('./interfaces/tarea.js');
const { EliminarTarea } = require('./interfaces/eliminarTarea.js');
const { NuevaTarea } = require('./interfaces/nuevaTarea.js');
const { Tareas } = require('./interfaces/tareas.js');
const { Chat } = require('./interfaces/chat.js');
const { Calendario } = require('./interfaces/calendario.js');
const { CompletitudTareas } = require('./interfaces/completitudTareas.js');
const { CompletitudGrafico } = require('./interfaces/completitudGrafico.js');
const { Recordatorio } = require('./interfaces/recordatorio.js');
const { Resumen } = require('./interfaces/resumen.js');
const { Uso } = require('./interfaces/uso.js');
const { Cuidador } = require('./interfaces/cuidador.js');
const { Satisfaccion } = require('./interfaces/satisfaccion.js');
const { Realizacion } = require('./interfaces/realizacion.js');
const { Premios } = require('./interfaces/premios.js');
const { Fijacion } = require('./interfaces/fijacion.js');
const { OrientacionTemporal } = require('./interfaces/orientacionTemporal.js');
const { OrientacionEspacial } = require('./interfaces/orientacionEspacial.js');
const { SecuenciaColores } = require('./interfaces/secuenciaColores.js');
const { CuestionarioSatisfaccion } = require('./interfaces/cuestionarioSatisfaccion.js');
const { CuestionarioUso } = require('./interfaces/cuestionarioUso.js');
const { Cuestionarios } = require('./interfaces/cuestionarios.js');

const { OPENAI_API_KEY } = require('./config');

// Firebase DB
const firebaseUrl = "https://app-ayuda-alexa-default-rtdb.europe-west1.firebasedatabase.app/Tareas";
const firebaseUrlCuestionarios = "https://app-ayuda-alexa-default-rtdb.europe-west1.firebasedatabase.app/Cuestionarios";

// S3 storage service
const aws = require('aws-sdk');
// Configure region
const s3 = new aws.S3();

// Variable de juego
var points = 0;
// Variable de cuestionarios
var cuestionarioUsoRealizado = false;
var cuestionarioSatisfaccionRealizado = false;

var tareaRealizada = null;
//Avatar seleccionado
var numeroAvatar = 0;

// Avatares 1 y 2 para cada pantalla
const videoAvatarPorPantalla = {
    1: {
        eliminarTarea : 'https://avatarok.s3.eu-west-3.amazonaws.com/eliminarTarea_chico.mp4',
        calendario: 'https://avatarok.s3.eu-west-3.amazonaws.com/calendario_chico.mp4',
        misTareas: 'https://avatarok.s3.eu-west-3.amazonaws.com/misTareas_chico.mp4',
        tareas: 'https://avatarok.s3.eu-west-3.amazonaws.com/tareas_chico.mp4',
        resumen: 'https://avatarok.s3.eu-west-3.amazonaws.com/resumen_chico.mp4',
        inicial: 'https://avatarok.s3.eu-west-3.amazonaws.com/inicial_chico.mp4'
    },
    2: {
        
        eliminarTarea: 'https://avatarok.s3.eu-west-3.amazonaws.com/eliminarTarea_chica.mp4',
        calendario: 'https://avatarok.s3.eu-west-3.amazonaws.com/calendario_chicA.mp4',
        misTareas: 'https://avatarok.s3.eu-west-3.amazonaws.com/misTareas_chicA.mp4',
        tareas: 'https://avatarok.s3.eu-west-3.amazonaws.com/tareas_chicA.mp4',
        resumen: 'https://avatarok.s3.eu-west-3.amazonaws.com/resumen_chicA.mp4',
        inicial: 'https://avatarok.s3.eu-west-3.amazonaws.com/inicial_chicA.mp4'
    }
};

const APLUserEventHandler = {
  canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent';
  },

  async handle(handlerInput) {

    const args = handlerInput.requestEnvelope.request.arguments || [];
    const evento = args[0];

    console.log("Evento recibido:", evento);
    console.log("Args completos:", args);

    // Mapa de funciones por botón
    const contenidoPorBoton = {
      cuestionarios: contenidoPaginaCuestionarios,
      cuestionarioCognitivo: cuestionarioOrientacionTemporal,
      cerrarCuestionario: contenidoPaginaCuestionarios,
      siguientePregunta: cuestionarioOrientacionEspacial,
      siguienteSeccion: cuestionarioFijacion,
      cuestionarioUso: cuestionarioUso,
      cuestionarioSatisfaccion: cuestionarioSatisfaccion,
      volverDeAvatares: contenidoPaginaBienvenida,
      volverDeHome: contenidoPaginaSeleccionCuidador,
      volverDeCalendario: contenidoPaginaInicial,
      volverDeChat: contenidoPaginaInicial,
      volverDeTareas: contenidoPaginaSeleccionCuidador,
      volverDeResumen: contenidoPaginaInicial,
      volverDeMisTareas: contenidoPaginaTareas,
      volverDeTarea: contenidoPaginaMisTareas,
      volverDeNuevaTarea: contenidoPaginaTareas,
      volverDeSatisfaccion: contenidoPaginaResumen,
      volverDeUso: contenidoPaginaResumen,
      volverDeCompletitudGrafico: contenidoPaginaResumen,
      volverDePremio: contenidoPaginaInicial,
      volverDeSecuenciaColores: contenidoPaginaCuestionarios,
      premioJuego: contenidoPaginaSecuenciaColores,
      premioVideo: abrirVideo,
      premioMusica: abrirMusica,
      cerrarRecordatorio: contenidoPaginaInicial,
      tareaRealizada: contenidoPaginaRealizacionTarea,
      verTarea: contenidoPaginaTarea,
      empezar: contenidoPaginaAvatares,
      usuario: contenidoPaginaInicial,
      cuidador: contenidoPaginaTareas,
      tareas: contenidoPaginaTareas,
      chat: contenidoPaginaChat,
      calendario: contenidoPaginaCalendario,
      resumen: contenidoPaginaResumen,
      tareasCompletadas: contenidoPaginaCompletitudTareas,
      satisfaccion: contenidoPaginaMiSatisfaccion,
      uso: contenidoPaginaMiUso,
      avatar: contenidoPaginaSeleccionCuidador,
      misTareas: contenidoPaginaMisTareas,
      nuevaTarea: contenidoPaginaNuevaTarea,
      eliminarTarea: contenidoPaginaEliminarTarea
    };

    const session = handlerInput.attributesManager.getSessionAttributes() || {};

    if (evento === 'checkTask') {
        const tareaActiva = await obtenerTareaRecordatorio();

        if (tareaActiva) {
            // 1. Obtener los datos COMPLETOS de la tarea
            const url = `${firebaseUrl}/${encodeURIComponent(tareaActiva)}.json`;
            const response = await axios.get(url);
            const tareaCompleta = response.data;
    
            if (!tareaCompleta.horaInicial) {
                // Caso: Primer recordatorio
                return contenidoPaginaRecordatorio(handlerInput, tareaActiva);
            } else { 
                // Caso: Ya tuvo recordatorio, verificar realización
                return contenidoPaginaRealizacionTarea(handlerInput, tareaActiva);
            }
        } 
        return handlerInput.responseBuilder
            .getResponse();
    
    } 

    if (evento in contenidoPorBoton) {
      const funcionContenido = contenidoPorBoton[evento];

      // Control de estado según botón
      switch (evento) {
        case 'volverDeChat':
          session.enChat = false;
          session.chatHistory = [];
          break;
        case 'volverDeSatisfaccion':
          session.enSatisfaccion = false;
          break;
        case 'volverDeUso':
          session.enUso = false;
          break;
        case 'volverDeTareas':
          session.enTareas = false;
          break;
        case 'volverDeNuevaTarea':
          session.enNuevaTarea = false;
          session.pasoCreacion = 0;
          session.tarea = {};
          break;
        case 'volverDeCompletitudTareas':
          session.esperandoTarea = false;
          break;
        case 'volverDeMisTareas':
          session.enMisTareas = false;
          break;
      }

      handlerInput.attributesManager.setSessionAttributes(session);
      return funcionContenido(handlerInput, args[1] || null);
    } 

    // Si no se reconoce el evento
    console.warn("Evento APL no reconocido:", evento);
    return handlerInput.responseBuilder
      .speak("No entendí la acción que quieres realizar.")
      .getResponse();
  }
};

// Devuelve el número de avatar de la sesión
function obtenerSlotNumero(handlerInput) {
    return numeroAvatar;
}

// Controlador de redirección a las páginas correspondientes. Decir cualquier cosa para lanzar este intent
const PaginaIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PaginaIntent';
    },
    handle(handlerInput) {
        
        // Mapeo de páginas a funciones
        const pageHandlers = {
            'sí': () => contenidoPaginaRealizacionTarea(handlerInput, 'sí'),
            'no': () => contenidoPaginaRealizacionTarea(handlerInput, 'no'),
            'empezar': () => contenidoPaginaAvatares(handlerInput),
            'usuario': () => contenidoPaginaInicial(handlerInput),
            'cuidador': () => contenidoPaginaTareas(handlerInput),
            'hombre': () => contenidoPaginaSeleccionCuidador(handlerInput, 1),
            'mujer': () => contenidoPaginaSeleccionCuidador(handlerInput, 2),
            'cerrar recordatorio': () => contenidoPaginaInicial(handlerInput),
            'video': () => abrirVideo(handlerInput),
            'musica': () => abrirMusica(handlerInput),
            'juego': () => contenidoPaginaSecuenciaColores(handlerInput),
            'mis tareas': () => contenidoPaginaMisTareas(handlerInput),
            'ver mis tareas': () => contenidoPaginaMisTareas(handlerInput),
            'crear tarea': () => contenidoPaginaNuevaTarea(handlerInput),
            'nueva tarea': () => contenidoPaginaNuevaTarea(handlerInput),
            'eliminar tarea': () => contenidoPaginaEliminarTarea(handlerInput),
            'chat': () => contenidoPaginaChat(handlerInput), 
            'asistente': () => contenidoPaginaChat(handlerInput), 
            'hablar con asistente': () => contenidoPaginaChat(handlerInput), 
            'hablar con el asistente': () => contenidoPaginaChat(handlerInput), 
            'calendario': () => contenidoPaginaCalendario(handlerInput),
            'ver calendario': () => contenidoPaginaCalendario(handlerInput),
            'ver calendario de tareas': () => contenidoPaginaCalendario(handlerInput),
            'progreso': () => contenidoPaginaResumen(handlerInput),
            'ver mi progreso': () => contenidoPaginaResumen(handlerInput),
            'mi progreso': () => contenidoPaginaResumen(handlerInput),
            'ver progreso': () => contenidoPaginaResumen(handlerInput),
            'tareas completadas': () => contenidoPaginaCompletitudTareas(handlerInput),
            'habilidad': () => contenidoPaginaMiUso(handlerInput),
            'mi habilidad': () => contenidoPaginaMiUso(handlerInput),
            'cuestionario':() => contenidoPaginaCuestionarios(handlerInput),
            'realizar cuestionario':() => contenidoPaginaCuestionarios(handlerInput),
            'cuestionario cognitivo':() => cuestionarioOrientacionTemporal(handlerInput),
            'cuestionario habilidad':() => cuestionarioUso(handlerInput),
            'cuestionario satisfaccion':() => cuestionarioSatisfaccion(handlerInput),
            'cuestionario de habilidad':() => cuestionarioUso(handlerInput),
            'cuestionario de satisfaccion':() => cuestionarioSatisfaccion(handlerInput)
        }
        
        const session = handlerInput.attributesManager.getSessionAttributes();
        const slots = handlerInput.requestEnvelope.request.intent.slots;

        const pagina = slots.pagina.value;
        const yesno = slots.yesno.value;
        const valoracion = slots.valoracion.value;
        const numero = slots.numero;
        const catchAllSlot = slots.catchAll;
        const catchAllValue = catchAllSlot && catchAllSlot.value ? catchAllSlot.value.trim().toLowerCase() : '';

        if (pageHandlers[pagina]) {
            return pageHandlers[pagina]();
        }

        if (session.enChat) {
            return contenidoPaginaChat(handlerInput, catchAllValue);
        } else if (session.enSatisfaccion) {
            return cuestionarioSatisfaccion(handlerInput, valoracion);
        } else if (session.enUso) {
            return cuestionarioUso(handlerInput, catchAllValue);
        } else if (session.enNuevaTarea) {
            return contenidoPaginaNuevaTarea(handlerInput, catchAllSlot); 
        } else if (session.enNuevaTarea && numero) {
            return contenidoPaginaNuevaTarea(handlerInput, numero);
        } else if (session.enMisTareas) { 
            return contenidoPaginaTarea(handlerInput, catchAllValue);
        } else if (session.enEliminarTarea) {
            return contenidoPaginaEliminarTarea(handlerInput, catchAllValue);
        } else if (session.enRecordatorio) { 
            return contenidoPaginaRealizacionTarea(handlerInput, yesno);
        } 
        
        const speakOutput = 'Lo siento, no entendí eso. ¿Podrías repetirlo o decir "ayuda"?';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
            
        }
    
};
        
const AvatarSelectionIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AvatarSelectionIntent');
    },
    handle(handlerInput) {
        const avatarName = handlerInput.requestEnvelope.request.intent.slots.nombreAvatar.value;
        const avatarNumber = avatarName.toLowerCase() === 'marcos' ? 1 : 2;
        return contenidoPaginaSeleccionCuidador(handlerInput, avatarNumber);
    }
};

// Decir "abrir aplicacion tareas" para lanzar este intent
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        return contenidoPaginaBienvenida(handlerInput);
    }
};

/* Inicio de juego de secuencia de colores. Decir secuencia de colores para activar este intent */
const ColorSequenceInitIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ColorSequenceInitIntent';
    }, 
    handle(handlerInput) {
        return contenidoPaginaSecuenciaColores(handlerInput);
    }
};

function contenidoPaginaSecuenciaColores(handlerInput) {
    try {
        // Inicializar puntos si no está definido
        if (typeof points === 'undefined') {
            points = 0;
        }
        
        // Mensajes por defecto si no están en requestAttributes
        const messages = {
            COLOR_SEQUENCE_MSG: '¡Vamos a jugar a la secuencia de colores! Te diré una lista de colores y tienes que repetirlos en el mismo orden. ¡Comenzamos!',
            LAUNCH_HEADER_MSG: 'Juego de Colores',
            COLORES_GAME_TEXT_MSG: (color) => `Repite: ${color}`,
            COLORES_GAME_HINT_MSG: 'Di el color que escuches',
            HELP_MSG: 'Por favor, di el color que escuches.'
        };
        
        let speakOutput = messages.COLOR_SEQUENCE_MSG;
        
        // Inicializar atributos de sesión
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes.screenMode = sessionAttributes.screenMode || 'light';
        sessionAttributes.fontSize = sessionAttributes.fontSize || 20;
        
        // Generar color aleatorio
        const colors = ['rojo', 'verde', 'azul', 'amarillo'];
        const nextcolor = colors[Math.floor(Math.random() * colors.length)];
        sessionAttributes.colorsequence = nextcolor;
        
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        speakOutput += 'Primera ronda: ' + nextcolor;

        // Configurar APL si está soportado
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.3', // Versión más estable
                document: SecuenciaColores,
                datasources: {
                    launchData: {
                        type: 'object',
                        properties: {
                            game: 'https://img.freepik.com/fotos-premium/papeles-colores-famosa-corporacion-informatica-logotipo-fabricante-software-colores-papel-rojo-verde-azul-amarillo-concepto-logotipo-corporacion-fondo-abstracto_77829-5440.jpg',
                            headerTitle: messages.LAUNCH_HEADER_MSG,
                            mainText:  messages.COLORES_GAME_TEXT_MSG(nextcolor),
                            hintString: messages.COLORES_GAME_HINT_MSG,
                            textSizeBody: sessionAttributes.fontSize,
                            textSizePrimary: sessionAttributes.fontSize + 10,
                            textSizeSecondary: sessionAttributes.fontSize + 5,
                            textSizeDetails: sessionAttributes.fontSize,
                            textSizeSecondaryHint: sessionAttributes.fontSize
                        },
                        transformers: [{
                            inputPath: 'hintString',
                            transformer: 'textToHint',
                        }]
                    },
                },
            });
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(messages.HELP_MSG)
            .getResponse();
            
    } catch (error) {
        console.error('Error en ColorSequenceInitIntentHandler:', error);
        return handlerInput.responseBuilder
            .speak('Lo siento, hubo un error al iniciar el juego de colores. Por favor, inténtalo de nuevo.')
            .getResponse();
    }
}

/* Respuesta del usuario en el juego de secuencia de colores */
const ColorSequenceIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ColorSequenceIntent';
    }, 
    handle(handlerInput) {
        try {
            
            // Mensajes por defecto
            const defaultMessages = {
                INCORRECT_COLOR_SEQUENCE_MSG: 'Ese no era el color correcto.',
                CORRECT_COLOR_SEQUENCE_MSG: (name) => `¡Correcto ${name}!`,
                MISTAKE_MSG: (points) => `Oh no, has perdido. Puntos obtenidos: ${points}`,
                HELP_MSG: 'Por favor, di el color que escuches.'
            };

            // Inicializar puntos si no está definido
            if (typeof points === 'undefined') {
                points = 0;
            }
            points += 10; // Incrementar puntos

            const { request } = handlerInput.requestEnvelope;
            let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
            
            // Verificar y inicializar atributos de sesión necesarios
            sessionAttributes.colorsequence = sessionAttributes.colorsequence || '';
            sessionAttributes.name = sessionAttributes.name || 'usuario';
            sessionAttributes.lastMonth = sessionAttributes.lastMonth || '';
            sessionAttributes.numColores = sessionAttributes.numColores || 0;
            sessionAttributes.totalPoints = sessionAttributes.totalPoints || 0;

            const currentSequence = sessionAttributes.colorsequence.split(' ').filter(Boolean);
            const lastColor = currentSequence[currentSequence.length - 1] || '';
            const userColor = request.intent.slots.usercolorsequence.value.toLowerCase() || '';

            let speakOutput = defaultMessages.INCORRECT_COLOR_SEQUENCE_MSG;

            // Verificar si el color coincide
            if (lastColor === userColor) {
                // Respuesta correcta
                speakOutput = defaultMessages.CORRECT_COLOR_SEQUENCE_MSG(sessionAttributes.name);

                // Añadir nuevo color aleatorio
                const colors = ['rojo', 'verde', 'azul', 'amarillo'];
                const newColor = colors[Math.floor(Math.random() * colors.length)];
                
                sessionAttributes.colorsequence = `${sessionAttributes.colorsequence} ${newColor}`.trim();
                speakOutput += ` Siguiente ronda: ${sessionAttributes.colorsequence}`;
            } else {
                // Respuesta incorrecta - actualizar estadísticas
                const timezone = 'Europe/Madrid';
                const today = moment().tz(timezone);
                const thisMonth = today.format('MMMM');

                if (sessionAttributes.lastMonth === thisMonth) {
                    sessionAttributes.numColores += 1;
                } else {
                    sessionAttributes.numColores = 1;
                    sessionAttributes.lastMonth = thisMonth;
                }

                sessionAttributes.totalPoints += points;
                speakOutput = defaultMessages.MISTAKE_MSG(points);
                
                // Resetear puntos para nueva partida
                points = 0;
            }

            // Guardar atributos actualizados
            handlerInput.attributesManager.setSessionAttributes(sessionAttributes);

            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(defaultMessages.HELP_MSG)
                .getResponse();

        } catch (error) {
            console.error('Error en ColorSequenceIntentHandler:', error);
            return handlerInput.responseBuilder
                .speak('Lo siento, hubo un error procesando tu respuesta en el juego de colores. ¿Quieres intentarlo de nuevo?')
                .reprompt('¿Quieres seguir jugando al juego de colores?')
                .getResponse();
        }
    }
};

function contenidoPaginaBienvenida(handlerInput) {
    const speakOutput = "¡¡Bienvenido a la aplicación CuidaMe!! Aquí podrás organizar tus tareas, hablar con un asistente y mucho más. Para usarla, puedes hablar o tocar la pantalla. Si quieres salir, puedes decir cerrar en cualquier momento. ¿Estás listo? Di empezar o toca el botón para continuar";
    const textoAPL = "¡¡Bienvenido a la aplicación de tareas!!";
    const image = "https://avatarok.s3.eu-west-3.amazonaws.com/logo.png";
    
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        const payload = {
            documentData: {
                title: textoAPL,
                imagen: image
            }
        };
        
        // 1. Renderiza el documento APL (sin comandos)
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'bienvenidaScreen',
            document: Bienvenida,
            datasources: payload
        });

    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(speakOutput)
        .getResponse();
}

function contenidoPaginaCuestionarios(handlerInput) {
     if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {

        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'cuestionarios',
            document: Cuestionarios
        });
            
    }
    const speakOutput = "¿Qué cuestionario deseas realizar? Dime: cuestionario cognitivo, cuestionario de satisfaccion o cuestionario de habilidad";
    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(speakOutput)
        .getResponse();
 }

// Tranforma la duración con el formato de tarea a minutos
function convertirDuracionATotalMinutos(duracionTexto) {
  if (!duracionTexto) return 0;

  duracionTexto = duracionTexto.toLowerCase();

  const minutos = duracionTexto.match(/(\d+)\s*minuto[s]?/);
  const horas = duracionTexto.match(/(\d+)\s*hora[s]?/);
  const segundos = duracionTexto.match(/(\d+)\s*segundo[s]?/);

  const totalMinutos = 
    (horas ? parseInt(horas[1]) * 60 : 0) +
    (minutos ? parseInt(minutos[1]) : 0) +
    (segundos ? Math.ceil(parseInt(segundos[1]) / 60) : 0);

  return totalMinutos;
}

// Devuelve la tarea cuya hora y día coincide con la hora y día actuales
async function obtenerTareaRecordatorio() {
  const url = firebaseUrl + '.json';
  const response = await axios.get(url);
  const tareasFirebase = response.data;

  if (!tareasFirebase) return null;

  // 1. Obtener hora actual en UTC (Date.now() ya es UTC)
  const ahoraUTC = new Date();
  const offsetEspana = 2 * 60 * 60 * 1000; // 2 horas en milisegundos (UTC+2)
  
  // 2. Obtén día y hora local para España
  const ahoraEspana = new Date(ahoraUTC.getTime() + offsetEspana);
  const dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
  const diaActual = dias[ahoraEspana.getDay()];

  for (const nombre in tareasFirebase) {
    const tarea = tareasFirebase[nombre];
    
    // Verifica día y que no haya sido realizada ya
    if (!Array.isArray(tarea.dias) || !tarea.dias.map(d => d.toLowerCase()).includes(diaActual) || tarea.dias[diaActual] === true) {
      continue;
    }

    // 3. Parsea la hora de la tarea (asumiendo formato "HH:MM" en hora local España)
    const [h, m] = tarea.hora.split(':').map(Number);
    const inicioEspana = new Date(ahoraEspana);
    inicioEspana.setHours(h, m, 0, 0);
    const inicioUTCms = inicioEspana.getTime() - offsetEspana; // Convertir a UTC

    const duracionMinutos = convertirDuracionATotalMinutos(tarea.duracion);
    const finUTCms = inicioUTCms + duracionMinutos * 60000;

    // Compara con la hora actual en UTC (Date.now())
    const ahoraUTCms = Date.now();
    if (ahoraUTCms >= inicioUTCms && ahoraUTCms <= finUTCms) {
      return nombre;
    }
  }
  return null;
}

function contenidoPaginaAvatares(handlerInput) {
    const speakOutput = '¿Quién quieres que te acompañe hoy? Di Hombre o Mujer o pulsa: Marcos o Carlota.';
        
    // Verificar si el dispositivo tiene pantalla, en este caso Alexa Show
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        // Crear una respuesta con APL para mostrar el avatar
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'avatar',
            document: Avatar
        });
            
    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(speakOutput)
        .getResponse();
}

function contenidoPaginaSeleccionCuidador(handlerInput, numero) {
     
    if (numero) {
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = {
            // Todos los flags se inicializan a false/undefined
            enChat: false,
            enSatisfaccion: false,
            enUso: false,
            enNuevaTarea: false,
            esperandoTarea: false,
            enMisTareas: false,
            enEliminarTarea: false,
            pasoCreacion: 0,
            tarea: {},
            chatHistory: []
        };
        // Guardar número de avatar seleccionado por el usuario en la sesión
        numeroAvatar = numero;
        attributesManager.setSessionAttributes(sessionAttributes);
    }

    // Mostrar pantalla de elección entre usuario y cuidador
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        // Crear una respuesta con APL para mostrar la selección del usuario/cuidador
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'seleccionCuidador',
            document: Cuidador
        });
            
    }
    
    const speakOutput = "Dime, ¿eres usuario o cuidador?";
    
    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(speakOutput)
        .getResponse();
    
}

function contenidoPaginaInicial(handlerInput) {
    
    const numero = obtenerSlotNumero(handlerInput);
    const speakOutput = "¿Qué quieres hacer ahora? Dime: Asistente, Calendario, Cuestionario o Progreso ";
    
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'homeScreen',
            document: HomePage,
            datasources: {
                datos: {
                    avatarSeleccionado: numero
                }
            }
        });
    }
    
        // Comprobar recordatorios de tareas 
    
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.ExecuteCommands',
        token: 'homeScreen',
        commands: [
            {
                type: 'SendEvent',
                arguments: ['checkTask']
            }
        ]
    });
    
    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt('¿Necesitas algo más?')
        .withShouldEndSession(false)
        .getResponse();
}

function contenidoPaginaTareas(handlerInput) {
    let speakOutput;
        
    const numero = obtenerSlotNumero(handlerInput);
    if (numero === 1) { // Avatar masculino
        
        // Establecida voz de hombre
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                                Página de Tareas. ¿Qué quieres hacer?
                                Dime: Ver mis Tareas, Crear Tarea o Eliminar Tarea
                        </prosody>
                        </voice>
                        </speak>`;
    } else { // Avatar femenino
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                    Página de Tareas. ¿Qué quieres hacer?
                                    Dime: Ver mis Tareas, Crear Tarea o Eliminar Tarea
                            </prosody>
                        </speak>`;
    }
    
    const payload = {
        documentData : {
            avatarUrl: videoAvatarPorPantalla[numero].tareas,
            title: speakOutput
        }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'tareasScreen',
                document: Tareas,
                datasources: payload
            });
    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt('¿Necesitas algo más?')
        .withShouldEndSession(false) // Opcional: mantén la sesión abierta
        .getResponse();
}

function procesarConOpenAI(chatHistory) {
    try {
        const response = request('POST', 'https://api.openai.com/v1/chat/completions', {
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${OPENAI_API_KEY}`,
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo',
                // Indicar a ChatGPT que cambie su forma de hablar para un contexto de usuario con limitaciones
                messages: [
                    { role: 'system', 
                    content: 'Speak clearly and simply, using short sentences and easy-to-understand words, in less than 200 characters. ' +
         'Use a kind and respectful tone, as if speaking to an elderly person who is not very familiar with technology. ' +
         'Avoid technical jargon and explain things with simple examples.'
                        
                    },
                    ...chatHistory
                ],
            }),
        });

        if (response.statusCode === 200) {
            const responseBody = JSON.parse(response.getBody('utf8'));
            return responseBody.choices[0].message.content;
        } else {
            console.error('OpenAI API failed:', response.statusCode, response.getBody('utf8'));
            return null;
        }
    } catch (error) {
        console.error('Error procesando OpenAI:', error.message);
        return null;
    }
}

function contenidoPaginaChat(handlerInput, catchAllValue) {
    const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    sessionAttributes.enChat = true;
    sessionAttributes.chatHistory = sessionAttributes.chatHistory || [];

    if (!catchAllValue && sessionAttributes.chatHistory.length === 0) {
        const initialSpeakOutput = 'Hola, soy tu asistente de chat. ¿Sobre qué quieres hablar?';
        const payload = {
            documentData: {
                lastIndex: 0,
                conversationMessages: []
            }
        };

        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'chatScreen',
                document: Chat,
                datasources: payload
            });
        }

        return handlerInput.responseBuilder
            .speak(initialSpeakOutput)
            .reprompt('¿Sobre qué quieres hablar?')
            .withShouldEndSession(false)
            .getResponse();
    }

    if (catchAllValue) {
        sessionAttributes.chatHistory.push({ role: 'user', content: catchAllValue });
    }

    const speakOutput = procesarConOpenAI(sessionAttributes.chatHistory);

    if (speakOutput) {
        sessionAttributes.chatHistory.push({ role: 'assistant', content: speakOutput });
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);

        const lastIndex = sessionAttributes.chatHistory.length - 1;

        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            const payload = {
                documentData: {
                    lastIndex,
                    conversationMessages: sessionAttributes.chatHistory
                }
            };
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'chatScreen',
                document: Chat,
                datasources: payload
            });

            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.ExecuteCommands',
                token: 'chatScreen',
                commands: [
                    {
                        type: 'ScrollToIndex',
                        componentId: 'chatHistorySequence',
                        index: lastIndex,
                        align: 'center'
                    }
                ]
            });
        }
    }

    const finalSpeakOutput = speakOutput || 'Lo siento, tengo problemas para responder ahora mismo.';
    const repromptText = 'Dime qué más quieres saber';
     return handlerInput.responseBuilder
        .speak(`${finalSpeakOutput} ${repromptText}`)
        .withShouldEndSession(false)
        .getResponse();
}

async function contenidoPaginaMisTareas(handlerInput) {
    const numero = obtenerSlotNumero(handlerInput);
    const session = handlerInput.attributesManager.getSessionAttributes();
    session.enMisTareas = true;
    handlerInput.attributesManager.setSessionAttributes(session);
    
    const url = firebaseUrl + '.json';
    let response, tareasFirebase;
    try {
        response = await axios.get(url);
        tareasFirebase = response.data || {};
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No se pudieron cargar las tareas. Inténtalo más tarde.")
            .getResponse();
    }
    
    const tareasData = Object.entries(tareasFirebase)
    .map(([nombre, info]) => ({
        nombre,
        descripcion: info.descripcion,
        hora: info.hora
    }))
    
    let speakOutput;
    const textoAPL = "Página con la lista de tus Tareas";
    
    if (numero === 1) { // Avatar Hombre
            
            // Establecida voz de hombre
            speakOutput = `<speak>
                            <voice name="Enrique">
                            <prosody rate="slow">
                                Página con la lista de tus Tareas. Di el nombre de la tarea que quieres consultar.
                            </prosody>
                            </voice>
                            </speak>`;
    } else { // Avatar mujer
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                Página con la lista de tus Tareas. Di el nombre de la tarea que quieres consultar.
                            </prosody>
                        </speak>`;
    }

    const payload = {
        documentData: {
            avatarUrl: videoAvatarPorPantalla[numero].misTareas, 
            tareas: tareasData,
            title: textoAPL
        }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'misTareasScreen',
            document: MisTareas,
            datasources: payload
        });
    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt('¿Necesitas algo más?')
        .withShouldEndSession(false)
        .getResponse();
    
}

// Comprueba si el usuario ha realizado la tarea o no
async function contenidoPaginaRealizacionTarea(handlerInput, respuesta) {
    
    const session = handlerInput.attributesManager.getSessionAttributes();
    const numero = obtenerSlotNumero(handlerInput) || 1;
    let speakOutput, speakOutput2;
    
    respuesta = respuesta.toLowerCase().trim();
    
    if (respuesta === 'sí' || respuesta === 'si') {
    // No hay que preguntar más veces
    session.enRecordatorio = false;
    const tarea = tareaRealizada;
    // Actualizar Firebase marcando la tarea como realizada en los días correspondientes
    try {
        // Primero obtener los datos actuales de la tarea de la BD
        const urlTareaPrincipal = `${firebaseUrl}/${encodeURIComponent(tarea)}.json`;
        let response, tareaData;
        
        response = await axios.get(urlTareaPrincipal);
        tareaData = response.data || {};
        
        // Validar que tenemos los datos necesarios
        
        if (!tareaData.descripcion) {
            throw new Error("No se encontraron datos válidos de la tarea");
        }

        const ahoraUTC = new Date();
        const offsetEspana = 2 * 60 * 60 * 1000; // 2 horas en milisegundos (UTC+2)
        const ahoraEspana = new Date(ahoraUTC.getTime() + offsetEspana);
        const dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
        const hoy = ahoraEspana.getDay();
        const diaActual = dias[hoy];
        
        // Crear copia del objeto días
        const diasActualizados = Object.assign({}, tareaData.dias);
        
        // Marcar el día actual como completado
        diasActualizados[diaActual] = true;
        
        // Resetear horaInicial y vecesIniciales a null en la tarea principal usando tareaData
        await axios.patch(urlTareaPrincipal, {
            descripcion: tareaData.descripcion,
            dias: diasActualizados,
            duracion: tareaData.duracion,
            periodo: tareaData.periodo,
            hora: tareaData.horaInicial || tareaData.hora, // Usar horaInicial si existe, sino hora actual
            veces: tareaData.vecesIniciales || tareaData.veces, // Usar vecesIniciales si existe, sino veces actual
            horaInicial: null,
            vecesIniciales: null
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        speakOutput2 = "¡Enhorabuena por completar la tarea !🎉 Elige tu PREMIO: vídeo, juego de memoria o música"
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'recordatorioScreen',
                document: Premios
            });
        }

        return handlerInput.responseBuilder
            .speak(speakOutput2)
            .reprompt('¿Necesitas algo más?')
            .withShouldEndSession(false)
            .getResponse();
            
    } catch (error) {
        console.error("Error actualizando tarea:", error);
        console.error("Error details:", error.message);
        console.error("Error stack:", error.stack);
        return handlerInput.responseBuilder
            .speak("Hubo un error al registrar la tarea como completada.")
            .getResponse();
    }
    
} else if (respuesta === 'no') {
    const tarea = tareaRealizada;
    session.tareaNoRealizada += 1;
    handlerInput.attributesManager.setSessionAttributes(session);
    const url = `${firebaseUrl}/${encodeURIComponent(tarea)}.json`;
    let response, tareaData;
    try {
        response = await axios.get(url);
        tareaData = response.data || {};
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No se pudieron cargar las tareas. Inténtalo más tarde.")
            .getResponse();
    }

    // Eliminar una vez 
    const veces = tareaData.veces - 1;
    await axios.patch(url, {
        descripcion: tareaData.descripcion,  
        hora: tareaData.hora,                
        dias: tareaData.dias,               
        duracion: tareaData.duracion,       
        periodo: tareaData.periodo,          
        veces: veces,
        vecesIniciales: tareaData.vecesIniciales || tareaData.veces 
    });
    
    // Si aún quedan veces, volver a preguntar pasado periodo tiempo
    if (tareaData.vecesIniciales && veces > 0) {
        const payload = {
            documentData: {
                nombre: respuesta,
                title: speakOutput
            }
        };
        

        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.ExecuteCommands',
            token: 'recordatorioScreen',
          commands: [
            { type: 'SendEvent', arguments: ['checkTask', tarea] }
            ]
            
        });
        
        // Programar próxima pregunta de realización
        const periodoMs = periodoAMilisegundos(tareaData.periodo);
        const [h, m] = tareaData.hora.split(':').map(Number);
        const ahora = new Date();
        const recordatorio = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate(), h, m);
        recordatorio.setTime(recordatorio.getTime() + periodoMs);
        
        const nuevaHora = `${recordatorio.getHours()}:${recordatorio.getMinutes().toString().padStart(2, '0')}`;

        await axios.patch(url, {
                    descripcion: tareaData.descripcion,  
                    hora: nuevaHora,
                    dias: tareaData.dias,                
                    duracion: tareaData.duracion,        
                    periodo: tareaData.periodo,          
                    veces: tareaData.veces               
                });
                
        
    } else if (veces === 0) { // Ya se ha preguntado sobre la realización de la tarea todas las veces

        // Restablecer a hora original y limpiar
        await axios.patch(url, {
            descripcion: tareaData.descripcion,  
            hora: tareaData.horaInicial,
            dias: tareaData.dias,                
            duracion: tareaData.duracion,        
            periodo: tareaData.periodo,          
            veces: tareaData.vecesIniciales,
            vecesIniciales: null,
            horaInicial: null
        });
        
    }
    
    if (session.tareaNoRealizada > 2) { // No ha realizado la tarea en más de 2 veces: ayuda con ChatGPT
        const speakOutput = "Vaya, veo que tienes problemas... Te llevo al chat para que te ayude con la tarea";
        session.enChat = true;
        session.chatContext = `Necesito ayuda con la tarea "${tarea}". Dime instrucciones para poder realizarla`;
        handlerInput.attributesManager.setSessionAttributes(session);
        return contenidoPaginaChat(handlerInput, session.chatContext);
    }
    
    // Volver a página inicial
    return contenidoPaginaInicial(handlerInput);
    
    
} else { // Estamos procesando la realización de la tarea
    tareaRealizada = respuesta;
    session.tareaNoRealizada = 0;
    handlerInput.attributesManager.setSessionAttributes(session);
    let speakOutput;
    if (numero === 1) {
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            ¿Ya has realizado la tarea? Di sí o no o haz clic en un botón
                        </prosody>
                        </voice>
                        </speak>`;
    } else {
        speakOutput = `<speak>
                            <prosody rate="slow">
                                ¿Ya has realizado la tarea? Di sí o no o haz clic en un botón
                            </prosody>
                        </speak>`;
    }

    const payload = {
        documentData: {
            nombre: respuesta,
            title: speakOutput
        }
    };
    
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'recordatorioScreen',
            document: Realizacion,
            datasources: payload
        });
    }
    
    return handlerInput.responseBuilder
        .speak(speakOutput)
        .withShouldEndSession(false) 
        .getResponse();
    }
}

function periodoAMilisegundos(periodo) {
    if (!periodo) return 0;
    
    const minutosMatch = periodo.match(/(\d+)\s*minuto/);
    const horasMatch = periodo.match(/(\d+)\s*hora/);
    
    if (minutosMatch) {
        return parseInt(minutosMatch[1]) * 60 * 1000;
    } else if (horasMatch) {
        return parseInt(horasMatch[1]) * 60 * 60 * 1000;
    }
    
    return 0; // Por defecto
}

async function contenidoPaginaRecordatorio(handlerInput, tarea) {
    const session = handlerInput.attributesManager.getSessionAttributes();
    const numero = obtenerSlotNumero(handlerInput) || 1;
    session.enRecordatorio = true;
    handlerInput.attributesManager.setSessionAttributes(session);
    
    // Tarea nueva a recordar
    const url = `${firebaseUrl}/${encodeURIComponent(tarea)}.json`;
    
    const response = await axios.get(url);
    const tareaData = response.data;
    const imagen = "https://avatarok.s3.eu-west-3.amazonaws.com/pastillas.png";
    

    if (!tareaData) {
        return handlerInput.responseBuilder
            .speak(`No encontré la tarea llamada ${tarea}`)
            .getResponse();
    }
    
    // Guardar hora inicial si no existe
    if (!tareaData.horaInicial) {
        await axios.patch(url, {
            horaInicial: tareaData.hora,
            descripcion: session.tarea.descripcion,
            dias: session.tarea.dias,
            duracion: session.tarea.duracion,
            periodo: session.tarea.periodo,
            hora: session.tarea.hora,
            vecesIniciales: tareaData.veces
        });
    }
    
    // Calcular próxima hora de recordatorio
    const periodoMs = periodoAMilisegundos(tareaData.periodo);
    const [h, m] = tareaData.hora.split(':').map(Number);
    const ahora = new Date();
    const recordatorio = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate(), h, m);
    recordatorio.setTime(recordatorio.getTime() + periodoMs);
    
    const nuevaHora = `${recordatorio.getHours()}:${recordatorio.getMinutes().toString().padStart(2, '0')}`;
    
    // Actualizar hora de próxima notificación
    await axios.patch(url, {
        descripcion: session.tarea.descripcion,
        dias: session.tarea.dias,
        duracion: session.tarea.duracion,
        periodo: session.tarea.periodo,
        hora: nuevaHora
    });
    
    // Insertar pausas entre pasos
    const descripcionTexto = tareaData.descripcion
    .map(p => `<break time="500ms"/>${p}`)
    .join(', luego, ');

    let speakOutput;
    if (numero === 1) {
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            HA LLEGADO LA HORA DE REALIZAR LA TAREA <emphasis level="strong">${tarea}</emphasis>! Sigue los siguientes pasos: ${descripcionTexto}. Y di cerrar recordatorio o pulsa el botón rojo para salir.
                        </prosody>
                        </voice>
                        </speak>`;
    } else {
        speakOutput = `<speak>
                            <prosody rate="slow">
                                HA LLEGADO LA HORA DE REALIZAR LA TAREA <emphasis level="strong">${tarea}</emphasis>! Sigue los siguientes pasos: ${descripcionTexto}. Y di cerrar recordatorio o pulsa el botón rojo para salir.
                            </prosody>
                        </speak>`;
    }
    
    const payload = {
        documentData: {
            nombre: tarea,
            pasos: tareaData.descripcion,
            hora: tareaData.hora,
            dias: tareaData.dias,
            duracion: tareaData.duracion,
            title: speakOutput,
            imagen: imagen
        }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'recordatorioScreen',
            document: Recordatorio,
            datasources: payload
        });
    }
    
    
    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.ExecuteCommands',
                        token: 'tareaScreen',
                        commands: [
                            {
                                type: 'SendEvent',
                                arguments: ['checkTask']
                            }
                        ]
                    });

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .withShouldEndSession(false) 
        .getResponse();
}

function cuestionarioOrientacionTemporal(handlerInput) {
    const texto = [
            "¿En qué año estamos?",
            "¿En qué estación?",
            "¿En qué día del mes?",
            "¿En qué mes?",
            "¿En qué día de la semana?"
        ].join("... ");
        
        return handlerInput.responseBuilder
            .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'orientacionTemporalScreen',
                document: OrientacionTemporal, 
                datasources: {} 
            })
            .speak("Vamos a comenzar con orientación temporal. Responde a cada pregunta en voz alta:" + texto)
            .reprompt("Responde a las preguntas en voz alta, por favor.")
            .getResponse();
}

function cuestionarioFijacion(handlerInput) {
        
        return handlerInput.responseBuilder
            .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'fijacionScreen',
                document: Fijacion, 
                datasources: {} 
            })
            .speak("Ahora vamos con el recuerdo inmediato. Repite en voz alta: Peseta-Caballo-Manzana" )
            .reprompt("Repite Peseta-Caballo-Manzana en voz alta, por favor.")
            .getResponse();
}

function cuestionarioOrientacionEspacial(handlerInput) {
    const texto = [
            "¿En qué lugar estamos?",
            "¿En qué planta o sala?",
            "¿En qué pueblo o ciudad?",
            "¿En qué provincia?",
            "¿En qué país o comunidad?"
        ].join("... ");
        
        return handlerInput.responseBuilder
            .addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'orientacionTemporalScreen',
                document: OrientacionEspacial, 
                datasources: {} 
            })
            .speak("Ahora vamos con la orientación espacial. Responde a cada pregunta en voz alta:" + texto)
            .reprompt("Responde a las preguntas en voz alta, por favor.")
            .getResponse();
}

async function contenidoPaginaTarea(handlerInput, tarea) {
    const numero = obtenerSlotNumero(handlerInput) || 1;
    const url = `${firebaseUrl}/${encodeURIComponent(tarea)}.json`;
    let response, tareaData;
    try {
        response = await axios.get(url);
        tareaData = response.data || {};
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No se pudieron cargar las tareas. Inténtalo más tarde.")
            .getResponse();
    }
    
    if (!tareaData) {
      return handlerInput.responseBuilder
        .speak(`No encontré la tarea llamada ${tarea}`)
        .getResponse();
    }
    
    let speakOutput;
    if (numero === 1) { // Avatar Hombre
            
        // Establecida voz de hombre
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            Aquí puedes ver la información de la tarea ${tarea}
                        </prosody>
                        </voice>
                        </speak>`;
    } else { // Avatar mujer
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                Aquí puedes ver la información de la tarea ${tarea}
                            </prosody>
                        </speak>`;
    }
    
    // 1. Definir días válidos (opcional, para filtrar propiedades no deseadas)
    const diasValidos = ["lunes", "martes", "miercoles", "miércoles", "jueves", "viernes", "sabado", "sábado", "domingo"];
    const dias = tareaData.dias;
    
    // 2. Separar días`
    console.log(dias);
    const { completados, noCompletados } = Object.keys(dias).reduce(
      (result, key) => {
        // Filtrar solo días válidos (opcional)
        if (!diasValidos.includes(key)) return result; 
    
        const valor = dias[key];
        const estaCompletado = valor === true || valor === "true" || valor === 1;
    
        if (estaCompletado) {
          result.completados.push(key);
        } else {
          result.noCompletados.push(key);
        }
        return result;
      },
      { completados: [], noCompletados: [] }
    );
    
    const payload = {
        documentData: {
            nombre: tarea,
            pasos: tareaData.descripcion,
            hora: tareaData.hora,
            completados: completados,
            noCompletados: noCompletados,
            duracion: tareaData.duracion
        }
    };
    
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'tareaScreen',
            document: Tarea,
            datasources: payload
        });
    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt('¿Necesitas algo más?')
        .withShouldEndSession(false) 
        .getResponse();
}

async function contenidoPaginaNuevaTarea(handlerInput, respuesta) {
    const session = handlerInput.attributesManager.getSessionAttributes();
    session.enNuevaTarea = true;
    session.tarea = session.tarea || {};
    session.pasoCreacion = session.pasoCreacion || 0;

    // Obtener la respuesta del usuario
    let userResponse = respuesta;
    if(!respuesta) {
        const intent = handlerInput.requestEnvelope.request.intent;
        const slots = intent && intent.slots ? intent.slots : {};
        const catchAllSlot = slots.catchAll;
        const catchAllValue = catchAllSlot && catchAllSlot.value ? catchAllSlot.value.trim().toLowerCase() : '';
        userResponse = catchAllValue;
    }

    let speakOutput = '';
    let repromptOutput = '';

    switch (session.pasoCreacion) {
        case 0: // Nombre
            
            if (userResponse) {
                session.tarea.nombre = userResponse && userResponse.value ? userResponse.value: '' ;
                session.pasoCreacion = 1;
                speakOutput = '¿Cómo se realiza la tarea? Describe los pasos, como "primero abre la puerta, luego sal"';
            } else {
                speakOutput = '¿Cómo se llama la nueva tarea?';
            }
            repromptOutput = speakOutput;
            break;

        case 1: // Descripción
        if (userResponse) {
            // Limpiar la respuesta
            const descripcionLimpia = userResponse.value.trim();
            
            // Opción 1: Si el usuario dice "primero X luego Y" (sin comas)
            if (/primero|luego|después|finalmente/i.test(descripcionLimpia)) {
                // Dividir por conectores naturales
                const pasos = descripcionLimpia.split(/(?:\bprimero\b|\bluego\b|\bdespués\b|\bfinalmente\b)/i)
                                              .map(p => p.trim())
                                              .filter(p => p.length > 0);
                
                session.tarea.descripcion = pasos; 
            } 
            // Opción 2: Descripción simple (un solo paso)
            else {
                session.tarea.descripcion = [descripcionLimpia]; // array de un único paso

            }
            
            session.pasoCreacion = 2;
            speakOutput = '¿Qué días de la semana se repite la tarea? Por ejemplo: "lunes y miércoles"';
        } else {
            speakOutput = 'Por favor, describe cómo se realiza la tarea. Ejemplo: "Primero abre la puerta luego sal"';
        }
        repromptOutput = speakOutput;
        break;
        
        case 2: // Días
            if (userResponse) {
                const dias = ['lunes', 'martes', 'miercoles', 'miércoles', 'jueves', 'viernes', 'sabado', 'sábado', 'domingo'];
                const diasReconocidos = dias.filter(dia => userResponse.value.toLowerCase().includes(dia));
                if (diasReconocidos.length > 0) {
                  session.tarea.dias = diasReconocidos;
                  session.pasoCreacion = 3;
                  speakOutput = '¿A qué hora querrás realizar esta tarea?'
                  
                } else {
                  speakOutput = 'No he reconocido ningún día. ¿Puedes repetirlo?';
                }
                repromptOutput = speakOutput;

            } else {
                speakOutput = '¿Qué días se debe realizar esta tarea?';
                repromptOutput = speakOutput;
            }
            break;

        case 3: // Hora
            if (userResponse) {
                 const horaRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
                if (horaRegex.test(userResponse.value)) {
                    session.tarea.hora = userResponse && userResponse.value ? userResponse.value: '' ;
                    session.pasoCreacion = 4;
                    speakOutput = '¿Cada cuánto tiempo quieres que te pregunte si has realizado la tarea? ¿5 minutos, 1 hora...?';
                } else {
                    speakOutput = 'No he entendido esa hora, repite por favor';
                }
                repromptOutput = speakOutput;
            } else {
                speakOutput = '¿A qué hora deberá realizarse la tarea? Por ejemplo: a las once de la mañana';
                repromptOutput = speakOutput;
            }
            break;
        case 4:    // Periodicidad de pregunta sobre la realización de tareas en el recordatorio
            if (userResponse) {
                session.tarea.periodo = userResponse;
                session.pasoCreacion = 5;
                speakOutput = '¿Cuántas veces quieres que te pregunte si has realizado la tarea? Dos veces, tres veces...';
            } else {
                speakOutput = '¿Cada cuánto tiempo quieres que te pregunte si has realizado la tarea?'

            }
            repromptOutput = speakOutput;
            break;
        case 5:    // Número de veces que se pregunta sobre la realización de tareas en el recordatorio
            if (userResponse) {
                session.tarea.veces = userResponse.value ;
                session.pasoCreacion = 6;
                speakOutput = '¿Cuánto tiempo durará la tarea? Por ejemplo: "30 minutos"';
                repromptOutput = speakOutput;
            } else {
                speakOutput = '¿Cuántas veces quieres que te pregunte si has realizado la tarea?';
                repromptOutput = speakOutput;
            }
            break;
        case 6: // Duración
            if (userResponse) {
                session.tarea.duracion = userResponse ;
                // Guardar en Firebase
                try {
                    const url = `${firebaseUrl}/${encodeURIComponent(session.tarea.nombre)}.json`;
                 
                    await axios.put(url, {
                        descripcion: session.tarea.descripcion,
                        hora: session.tarea.hora,
                        dias: session.tarea.dias,
                        duracion: session.tarea.duracion,
                        periodo: session.tarea.periodo,
                        veces: session.tarea.veces
                    });
                    // 1. Definir días válidos (opcional, para filtrar propiedades no deseadas)
                    const diasValidos = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"];
                    const dias = session.tarea.dias;
                    
                    // 2. Separar días`
                    console.log(dias);
                    const { completados, noCompletados } = Object.keys(dias).reduce(
                      (result, key) => {
                        // Filtrar solo días válidos (opcional)
                        if (!diasValidos.includes(key)) return result; 
                    
                        const valor = dias[key];
                        const estaCompletado = valor === true || valor === "true" || valor === 1;
                    
                        if (estaCompletado) {
                          result.completados.push(key);
                        } else {
                          result.noCompletados.push(key);
                        }
                        return result;
                      },
                      { completados: [], noCompletados: [] }
                    );
                    
                    // Reunir datos de tarea
                    const payload = {
                        documentData: {
                            nombre: session.tarea.nombre,
                            pasos: session.tarea.descripcion,
                            hora: session.tarea.hora,
                            completados: completados,
                            noCompletados: noCompletados,
                            duracion: session.tarea.duracion,
                            title: "Tarea creada correctamente"
                        }
                    };
                    
                    // Mostrar datos de la tarea ya guardada
                    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            token: 'tareaScreen',
                            document: Tarea,
                            datasources: payload
                        });
                    }
                    
                        // 2. Comprobar recordatorios de tareas 
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.ExecuteCommands',
                        token: 'tareaScreen',
                        commands: [
                            {
                                type: 'SendEvent',
                                arguments: ['checkTask']
                            }
                        ]
                    });
                    
                    speakOutput = `Tarea "${session.tarea.nombre}" guardada correctamente.`;
                    // Resetear flags
                    session.enNuevaTarea = false;
                    session.pasoCreacion = 0;
                    session.tarea = {};
                    handlerInput.attributesManager.setSessionAttributes(session);
                    
                    return handlerInput.responseBuilder
                        .speak(speakOutput)
                        .getResponse();
                    
                        
                } catch (error) {
                    console.error("Error al guardar en Firebase:", error);
                    speakOutput = 'Hubo un error al guardar la tarea. Por favor, inténtalo de nuevo.';
                }
            } else {
                speakOutput = '¿Cuánto tiempo dura aproximadamente la tarea?';
                repromptOutput = speakOutput;
            }
            
    }

    // Renderizar pantalla 
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'nuevaTareaToken',
            document: NuevaTarea,
            datasources: {
                documentData: {
                    title: "Creando nueva tarea",
                    pasoActual: session.pasoCreacion + 1
                }
            }
        });
    }

    handlerInput.attributesManager.setSessionAttributes(session);

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt(repromptOutput)
        .getResponse();
}

/* Hora de la nueva tarea que está siendo creada. Decir una hora para lanzar este intent */
const PaginaNuevaTareaHoraIntentHandler = {
    canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
      && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PaginaNuevaTareaHoraIntent';
  },

  async handle(handlerInput) {
    const slots = handlerInput.requestEnvelope.request.intent.slots;
    const session = handlerInput.attributesManager.getSessionAttributes();
    if (slots.hora.value) {
        if (session.enNuevaTarea ) {
            return await contenidoPaginaNuevaTarea(handlerInput, slots.hora);
        } else if(session.enChat) {
            return contenidoPaginaChat(handlerInput, slots.nombre);
        } else if(session.enSatisfaccion) {
            return cuestionarioSatisfaccion(handlerInput);
        }
    } else if (slots.numero.value) {
        return await contenidoPaginaNuevaTarea(handlerInput, slots.numero.value);
    }
    else {
        const speakOutput = "No entendí lo que dijiste, prueba de nuevo.";
        return handlerInput.responseBuilder
        .reprompt("")
        .speak(speakOutput)
        .getResponse();
    }

  }
}

/* Número de veces de la nueva tarea que está siendo creada. Decir un número para activar este intent */
const PaginaNuevaTareaNumeroIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PaginaNuevaTareaNumeroIntent';
    },
    
    async handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        const session = handlerInput.attributesManager.getSessionAttributes();
        
        if (session.enNuevaTarea && slots.numero && slots.numero.value) {
            return await contenidoPaginaNuevaTarea(handlerInput, slots.numero);
        } else {
            const speakOutput = "No entendí el número de veces. Por favor, dime un número.";
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
        }
    }
};

/* Nombre de la nueva tarea que está siendo creada. Decir únicamente un verbo para lanzar este intent */
const PaginaNuevaTareaNombreIntentHandler = {
    canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
      && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PaginaNuevaTareaNombreIntent';
  },

  async handle(handlerInput) {
    const slots = handlerInput.requestEnvelope.request.intent.slots;
    const session = handlerInput.attributesManager.getSessionAttributes();
    
    if (!slots.nombre.value) {
        const speakOutput = "No entendí lo que dijiste, por favor prueba de nuevo.";
        return handlerInput.responseBuilder
            .reprompt("")
            .speak(speakOutput)
            .getResponse();
    }
    
    const nombre = slots.nombre.value;
    
    if (session.enNuevaTarea) {
        return contenidoPaginaNuevaTarea(handlerInput, slots.nombre);
    }
    
    if (session.enChat) {
        return contenidoPaginaChat(handlerInput, slots.nombre);
    }
    
    if (session.enEliminarTarea) {
        return contenidoPaginaEliminarTarea(handlerInput, nombre);
    }
    
    if (session.enMisTareas) {
        return await contenidoPaginaTarea(handlerInput, nombre);
    }
    
    // Por defecto, mensaje de error
    const speakOutput = "No entendí lo que dijiste, prueba de nuevo por favor.";
    return handlerInput.responseBuilder
        .reprompt("")
        .speak(speakOutput)
        .getResponse();

  }
}

/* Duración de la nueva tarea que está siendo creada. Decir una duración para lanzar este intent */
const PaginaNuevaTareaDuracionIntentHandler = {
    canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
      && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PaginaNuevaTareaDuracionIntent';
    },

  async handle(handlerInput) {
    const slots = handlerInput.requestEnvelope.request.intent.slots;
    const session = handlerInput.attributesManager.getSessionAttributes();
    if (session.enNuevaTarea && slots.duracion.value) {
        return await contenidoPaginaNuevaTarea(handlerInput, parseDuracionISO(slots.duracion.value));
    } else {
        const speakOutput = "No entendí lo que dijiste, prueba de nuevo por favor.";
        return handlerInput.responseBuilder
        .reprompt("")
        .speak(speakOutput)
        .getResponse();
    }

  }
}

// Transforma la duración de la tarea en formato legible y entendible
function parseDuracionISO(input) {
    if (!input) return 'Duración no especificada';

    // Caso 1: Si ya está en formato natural
    if (typeof input === 'string' && !input.startsWith('P')) {
        if (/(\d+|una|un)\s*(hora|minuto|segundo)/i.test(input)) {
            return input;
        }
        return 'Formato no reconocido';
    }

    // Caso 2: Formato ISO 8601
    const isoRegex = /^P(?!$)(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)D)?(?:T(?!$)(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/i;
    const match = String(input).match(isoRegex);
    if (!match) return 'Formato ISO inválido';

    const horas = match[4] ? parseInt(match[4]) : 0;
    const minutos = match[5] ? parseInt(match[5]) : 0;
    const segundos = match[6] ? parseInt(match[6]) : 0;

    const partes = [];
    if (horas > 0) partes.push(`${horas} ${horas === 1 ? 'hora' : 'horas'}`);
    if (minutos > 0) partes.push(`${minutos} ${minutos === 1 ? 'minuto' : 'minutos'}`);
    if (segundos > 0 && horas === 0) partes.push(`${segundos} ${segundos === 1 ? 'segundo' : 'segundos'}`);

    return partes.length ?
        partes.join(' y ').replace(/, ([^,]*)$/, ' y $1') :
        '0 minutos';
}

async function contenidoPaginaEliminarTarea(handlerInput, tarea) {

    const numero = obtenerSlotNumero(handlerInput);
    const session = handlerInput.attributesManager.getSessionAttributes();
    session.enEliminarTarea = true;

    const url = firebaseUrl + '.json';
    let response, tareasFirebase;
    try {
        response = await axios.get(url);
        tareasFirebase = response.data;
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No se pudieron cargar las tareas. Inténtalo más tarde.")
            .getResponse();
    }
    
    let textoAPL;
    
    if(!tareasFirebase) {
       textoAPL = "No hay tareas que eliminar"; 
    } else {
        textoAPL = "¿Qué tarea quieres eliminar?";
    }
    
    let speakOutput;
    if (numero === 1) { // Avatar Hombre
            
        // Establecida voz de hombre
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            Página para eliminar tareas. Di el nombre de la tarea que quieras eliminar
                        </prosody>
                        </voice>
                        </speak>`;
    } else { // Avatar mujer
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                Página para eliminar tareas. Di el nombre de la tarea que quieras eliminar
                            </prosody>
                        </speak>`;
    }
    
    const tareasData = Object.entries(tareasFirebase).map(([nombre, info]) => ({
        nombre,
        descripcion: info.descripcion,
        hora: info.hora
    }));
    
    const payload = {
        documentData: {
            avatarUrl: videoAvatarPorPantalla[numero].eliminarTarea, 
            tareas: tareasData,
            title: textoAPL
        }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'eliminarTareaScreen',
                document: EliminarTarea,
                datasources: payload
            });
    }

    
    if (!tarea) {
        return handlerInput.responseBuilder
            .speak("Por favor, dime qué tarea quieres eliminar.")
            .reprompt("¿Cómo se llama la tarea que quieres eliminar?")
            .getResponse();
    }

    const urlTarea = `${firebaseUrl}/${encodeURIComponent(tarea)}.json`;

    try {
        // Verificar si existe
        response = await axios.get(urlTarea);
        const tareaData = response.data;
        if (!tareaData) {
            return handlerInput.responseBuilder
                .speak(`La tarea ${tarea} no existe.`)
                .getResponse();
        }
        // Eliminar la tarea
        await axios.delete(urlTarea);
        //TODO: mensaje la tarea se ha eliminado
        // Mostrar pantalla actualizada
        return contenidoPaginaEliminarTarea(handlerInput);
    } catch (err) {
        console.error("Error eliminando la tarea:", err);
        return handlerInput.responseBuilder
            .speak("Ha ocurrido un error al eliminar la tarea. Por favor, inténtalo más tarde.")
            .getResponse();
    }

}

async function contenidoPaginaCalendario(handlerInput) {
    const numero = obtenerSlotNumero(handlerInput) || 1;
    const url = firebaseUrl + '.json';

    let tareasFirebase = {};
    try {
        const response = await axios.get(url);
        tareasFirebase = response.data || {};
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No pude obtener las tareas del calendario.")
            .getResponse();
    }

    const tareasData = Object.entries(tareasFirebase).map(([nombre, info]) => ({
        nombre,
        descripcion: info.descripcion || {},
        hora: info.hora || "00:00",
        duracion: info.duracion || "0",
        dias: info.dias || []
    }));

    const diasSemana = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];

    function horaEnMinutos(hora) {
        const [h, m] = hora.split(":").map(Number);
        return h * 60 + m;
    }
    
    // Agrupar tareas por día
    const calendario = diasSemana.map(dia => {
        const tareasDelDia = tareasData
            // Recorrer tareas y filtrar las que son del día correspondiente
            .filter(t => {
            if (!t.dias) return false; // Si no hay días, descartar
            
            // Caso 1: Es un array
            if (Array.isArray(t.dias)) {
                return t.dias.some(d => 
                    d.toString().toLowerCase() === dia.toLowerCase()
                );
            }
            
            // Caso 2: Es un objeto como {lunes: true, martes: false}
            if (typeof t.dias === 'object' && t.dias !== null) {
                return t.dias[dia] === true || 
                       t.dias[dia.toLowerCase()] === true;
            }
            
            // Caso 3: Es un string ("lunes martes")
            if (typeof t.dias === 'string') {
                return t.dias.toLowerCase().split(/\s+/).includes(dia.toLowerCase());
            }
            
            return false;
        })
            // Ordenar tareas en orden creciente de hora
            .sort((a, b) => horaEnMinutos(a.hora) - horaEnMinutos(b.hora))
            .map(t => `${t.hora} - ${t.nombre} `);
            console.log(dia);
            console.log(tareasDelDia);
        return {
            dia,
            tareas: tareasDelDia
        };
    });

    // Dividir en dos filas
    const calendarioFila1 = calendario.slice(0, 4); // lunes a jueves
    const calendarioFila2 = calendario.slice(4);    // viernes a domingo
    
    let speakOutput;
    if (numero === 1) { // Avatar Hombre
            
        // Establecida voz de hombre
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            Aquí tienes tu calendario con las tareas para esta semana.
                        </prosody>
                        </voice>
                        </speak>`;
    } else { // Avatar mujer
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                Aquí tienes tu calendario con las tareas para esta semana.
                            </prosody>
                        </speak>`;
    }
    
    const payload = {
        documentData: {
            avatarUrl: videoAvatarPorPantalla[numero].calendario,
            calendarioFila1,
            calendarioFila2
        }
    };

    try {
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'calendarioScreen',
                document: Calendario, 
                datasources: payload
            });
        }
        
    } catch (error) {
        console.error("Error details:", error.message);
        console.error("Error stack:", error.stack);
    }
    
        // 2. Comprobar recordatorios de tareas 
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.ExecuteCommands',
        token: 'calendarioScreen',
        commands: [
            {
                type: 'SendEvent',
                arguments: ['checkTask']
            }
        ]
    });

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt("¿Quieres hacer algo más con tus tareas?")
        .getResponse();
}

function contenidoPaginaResumen(handlerInput) {
    const numero = obtenerSlotNumero(handlerInput) || 1;
    
    let speakOutput;
    if (numero === 1) { // Avatar Hombre
            
        // Establecida voz de hombre
        speakOutput = `<speak>
                        <voice name="Enrique">
                        <prosody rate="slow">
                            Página de Progreso. Aquí puedes ver tu evolución en la aplicación.
                            ¿Qué quieres ver? Dime: mis tareas completadas, mi satisfacción o mi habilidad.
                        </prosody>
                        </voice>
                        </speak>`;
    } else { // Avatar mujer
        // Rate slow para que hable despacio y cuadre con el avatar al hablar.
        speakOutput = `<speak>
                            <prosody rate="slow">
                                Página de Progreso. Aquí puedes ver tu evolución en la aplicación.
                                ¿Qué quieres ver? Dime: tareas completadas, mi satisfacción o mi habilidad.
                            </prosody>
                        </speak>`;
    }
    

    const payload = {
        documentData: {
            avatarUrl: videoAvatarPorPantalla[numero].resumen,
            title: speakOutput
        }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'resumenToken',
            document: Resumen,
            datasources: payload
        });
    }
    
     return handlerInput.responseBuilder
        .speak(speakOutput)
        .reprompt("¿Qué más quieres hacer?")
        .getResponse();
}

async function contenidoPaginaMiSatisfaccion(handlerInput) {
  try {
    const numero = obtenerSlotNumero(handlerInput);
    const url = firebaseUrlCuestionarios + '.json';
    const response = await axios.get(url);

    const satisfaccion = response.data.satisfaccion;

    if (!satisfaccion) {
      // No hay dato aunque la URL exista
      const speakOutput = "Todavía no se ha realizado el cuestionario de satisfacción";

      const payload = {
        documentData: {
          numero: 0,
          imagenPastel: "https://cdn-icons-png.flaticon.com/512/565/565547.png", // icono neutro
          valorTexto: "Sin resultados"
        }
      };

      if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
          type: 'Alexa.Presentation.APL.RenderDocument',
          token: 'satisfaccionToken',
          document: Satisfaccion,
          datasources: payload
        });
      }

      return handlerInput.responseBuilder
        .speak(speakOutput)
        .getResponse();
    }

    // Si existe satisfaccion → convertir a número y mostrar gráfico
    const respuesta = parseInt(satisfaccion, 10);
    const valor = respuesta * 2; // Convertir 1-5 a 2-10

    const graficos = [
      "https://graficopastel.s3.eu-west-3.amazonaws.com/pastel_20.jpg",
      "https://graficopastel.s3.eu-west-3.amazonaws.com/pastel_40.jpg",
      "https://graficopastel.s3.eu-west-3.amazonaws.com/pastel_60.jpg",
      "https://graficopastel.s3.eu-west-3.amazonaws.com/pastel_80.jpg",
      "https://graficopastel.s3.eu-west-3.amazonaws.com/pastel_100.jpg"
    ];

    const valorTexto = ["Muy bajo", "Bajo", "Medio", "Alto", "Excelente"];

    const payload = {
      documentData: {
        numero: valor,
        imagenPastel: graficos[respuesta - 1],
        valorTexto: valorTexto[respuesta - 1]
      }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        token: 'satisfaccionToken',
        document: Satisfaccion,
        datasources: payload
      });
    }

    const speakOutput = "Gracias por tu valoración de la aplicación";
    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();

  } catch (error) {
    console.error("Error al obtener cuestionario de satisfacción:", error);

    const speakOutput = "Todavía no se ha realizado el cuestionario de satisfacción";

    const payload = {
      documentData: {
        numero: 0,
        imagenPastel: "https://cdn-icons-png.flaticon.com/512/463/463612.png", // icono error
        valorTexto: "Error al cargar"
      }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        token: 'satisfaccionToken',
        document: Satisfaccion,
        datasources: payload
      });
    }

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  }
}


function cuestionarioSatisfaccion(handlerInput, respuesta) {
    
    // Obtener día actual
    const ahoraUTC = new Date();
    const offsetEspana = 2 * 60 * 60 * 1000; // 2 horas en milisegundos (UTC+2)
    const ahoraEspana = new Date(ahoraUTC.getTime() + offsetEspana);
    const dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
    const diaActual = dias[ahoraEspana.getDay()];
    
    if ((diaActual === 'viernes')  && !cuestionarioSatisfaccionRealizado) {
        const session = handlerInput.attributesManager.getSessionAttributes();
        session.enSatisfaccion = true;
        
        handlerInput.attributesManager.setSessionAttributes(session);
        
        const speakOutput = "Por favor, valora la aplicación del 1 al 5. ¿Cuánto te gusta esta aplicación?";
        
        const payload = {
            documentData : {
                title: speakOutput
            }
        }
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'cuestionarioSatisfaccionToken',
                document: CuestionarioSatisfaccion, 
                datasources: payload
            });
        }
        
        if (!respuesta || respuesta < 1 || respuesta > 5) {
            return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt("Del 1 al 5, siendo 1 'No me gusta' y 5 'Me encanta'")
            .getResponse();
            
        } else {
            // Guardar respuesta en BD
            const url = firebaseUrlCuestionarios + '.json';
            axios.patch(url, {
                satisfaccion: respuesta
            })
            
            cuestionarioSatisfaccionRealizado = true;
            
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    token: 'cuestionariosToken',
                    document: Cuestionarios, 
                    datasources: payload
                });
            }
    
            return handlerInput.responseBuilder
            .speak("Gracias por tu valoración")
            .getResponse();
        }
    } else {// Ya se ha realizado el cuestionario esta semana
        const speakOutput = "Ya has realizado el cuestionario esta semana. Vuelve la semana que viene";
        
        const payload = {
            documentData : {
                title: speakOutput
            }
        }
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    token: 'cuestionariosToken',
                    document: Cuestionarios, 
                    datasources: payload
                });
        }
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
        
    }
}

function cuestionarioUso(handlerInput, respuesta) {
    
    // Obtener día actual
    const ahoraUTC = new Date();
    const offsetEspana = 2 * 60 * 60 * 1000; // 2 horas en milisegundos (UTC+2)
    const ahoraEspana = new Date(ahoraUTC.getTime() + offsetEspana);
    const dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
    const diaActual = dias[ahoraEspana.getDay()];

    // Verificar si es el día actual y no se ha realizado el cuestionario esta semana

    if ((diaActual === 'viernes')  && !cuestionarioUsoRealizado) {
        const session = handlerInput.attributesManager.getSessionAttributes();
        session.enUso = true;
        
        handlerInput.attributesManager.setSessionAttributes(session);
        
        const speakOutput = "¿Te ha resultado fácil o difícil utilizar esta aplicación? ";
        
        const payload = {
            documentData : {
                title: speakOutput
            }
        }
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'cuestionarioUsoToken',
                document: CuestionarioUso, 
                datasources: payload
            });
        }
        
        if (!respuesta) {
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt("Por favor, di fácil o difícil")
                .getResponse();
        } else {
            // Guardar respuesta en BD
            const url = firebaseUrlCuestionarios + '.json';
            axios.patch(url, {
                facilidad: respuesta
            })
            cuestionarioUsoRealizado = true;
            
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                token: 'cuestionariosToken',
                document: Cuestionarios, 
                datasources: payload
            });
        }
            
            return handlerInput.responseBuilder
            .speak("Gracias por tu respuesta")
            .getResponse();
        }
    } else { // Ya se ha realizado el cuestionario esta semana
        const speakOutput = "Ya has realizado el cuestionario esta semana. Vuelve la semana que viene";
    
        const payload = {
            documentData : {
                title: speakOutput
            }
        }
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    token: 'cuestionariosToken',
                    document: Cuestionarios, 
                    datasources: payload
                });
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
    
}

async function contenidoPaginaMiUso(handlerInput) {
  try {
    const url = firebaseUrlCuestionarios + '.json';
    const response = await axios.get(url);

    const facilidad = response.data.facilidad;

    if (!facilidad) {
      // No hay dato en la BD aunque la URL exista
      const speakOutput = "Todavía no se ha realizado el cuestionario de habilidad con la app";

      return handlerInput.responseBuilder
        .speak(speakOutput)
        .getResponse();
    }

    // Si sí existe la facilidad → procesar normalmente
    const txt = facilidad.toLowerCase();
    const esPositivo = txt.includes("fácil") || txt.includes("facil");

    let feedback, imagen, color;
    if (esPositivo) {
      feedback = "¡Me alegra que te resulte fácil!";
      color = "#2E7D32";
      imagen = "https://cdn-icons-png.flaticon.com/512/2583/2583344.png";
    } else {
      feedback = "Entendido, trabajaré para mejorar la experiencia.";
      color = "#C62828";
      imagen = "https://cdn-icons-png.flaticon.com/512/2583/2583439.png";
    }

    const payload = {
      documentData: {
        feedback,
        color,
        imagen,
        title: "Gracias por tu opinión sobre la facilidad de uso"
      }
    };

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        token: 'usoToken',
        document: Uso,
        datasources: payload
      });
    }

    return handlerInput.responseBuilder
      .speak("Gracias por tu feedback")
      .getResponse();

  } catch (error) {
    console.error("Error al obtener cuestionario de uso:", error);

    // Aquí entramos si la URL no existe o hay error de red
    const speakOutput = "Todavía no se ha realizado el cuestionario de habilidad con la app";

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  }
}


async function contenidoPaginaCompletitudTareas(handlerInput) {
    const session = handlerInput.attributesManager.getSessionAttributes();
    const numero = session.avatarSeleccionado;

    const url = firebaseUrl + '.json';
    let response, tareasFirebase;
    try {
        response = await axios.get(url);
        tareasFirebase = response.data || {};
    } catch (error) {
        console.error("Error obteniendo tareas:", error);
        return handlerInput.responseBuilder
            .speak("No se pudieron cargar las tareas. Inténtalo más tarde.")
            .getResponse();
    }

    // Filtrar tareas realizadas con algún === true
      // 1. Obtener hora actual en UTC (Date.now() ya es UTC)
      const ahoraUTC = new Date();
      const offsetEspana = 2 * 60 * 60 * 1000; // 2 horas en milisegundos (UTC+2)
      
      // 2. Obtén día y hora local para España
      const ahoraEspana = new Date(ahoraUTC.getTime() + offsetEspana);
      const dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
      const diaActual = dias[ahoraEspana.getDay()];
  
    const tareasCompletadas = Object.entries(tareasFirebase)
     .filter(([_, data]) => {
    // si no hay dias o no es un objeto, se marca como no realizada
    if (!data.dias || typeof data.dias !== "object") return false;
        // mirar si tiene algún día completado
        return Object.values(data.dias).some(v => v === true);
      })
    
    .map(([nombre, data]) => {
    try {
      const descripcion = (typeof data.descripcion === 'string') ? data.descripcion : '';
      const hora = (typeof data.hora === 'string') ? data.hora : '';
      // Obtener los días activos 
      const diasActivos = Object.entries(data.dias || {})
      .filter(([_, v]) => v === true)
      .map(([d]) => d)
      .join(', ');
      
      return {
        nombre: String(nombre),
        descripcion,
        hora,
        diasActivos 
      };
    } catch (e) {
      console.error('Error en map con la tarea:', nombre, data, e);
      return {
        nombre: String(nombre),
        descripcion: '',
        hora: '',
        diasActivos: diaActual,
      };
    }
  });
    
    let speakOutput;
    const totalTareas = Object.keys(tareasFirebase || {}).length;
    const numCompletadas = tareasCompletadas.length;

    if(totalTareas > 0 && numCompletadas/totalTareas >= 0.6 ) {
        speakOutput = `Has completado ${numCompletadas} de ${totalTareas} tareas esta semana... ¡Buen trabajo! 🎉`;
    } else {
        speakOutput = `Has completado ${numCompletadas} de ${totalTareas} tareas esta semana... ¡Ánimo!, seguro que remontas pronto  :)`;
    }

    const payload = {
        documentData: {
            title: speakOutput,
            tareas: tareasCompletadas, 
            numCompletadas,
            total: totalTareas
        }
    };

    // Mostrar gráfico APL
    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            token: 'completitudGraficoScreen',
            document: CompletitudGrafico,
            datasources: payload
        });
    }

    return handlerInput.responseBuilder
        .speak(speakOutput)
        .withShouldEndSession(false)
        .getResponse();
}

function abrirMusica(handlerInput) {
    const token = 'openYouTubeToken';

    // Renderizar documento con mensaje centrado
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        token: token,
        document: {
            type: "APL",
            version: "1.8",
            settings: {
                allowOpenURL: true // Permitir abrir URL
            },
            mainTemplate: {
                parameters: ["payload"],
                items: [
                    {
                        type: "Container",
                        width: "100vw",
                        height: "100vh",
                        justifyContent: "center",
                        alignItems: "center",
                        items: [
                            {
                                type: "Text",
                                text: "Abriendo YouTube...",
                                fontSize: "32dp",
                                fontWeight: "bold",
                                color: "white",
                                textAlign: "center"
                            }
                        ]
                    }
                ]
            }
        }
    });

    // Ejecutar OpenURL sobre el mismo token
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.ExecuteCommands',
        token: token,
        commands: [
            {
                type: 'OpenURL',
                source: 'https://www.youtube.com/watch?v=TdWEhMOrRpQ&list=RDTdWEhMOrRpQ&start_radio=1&ab_channel=AndreaBocelliVEVO'
            }
        ]
    });

    // Mensaje por voz
    return handlerInput.responseBuilder
        .speak("Abriendo YouTube")
        .getResponse();
}


function abrirVideo(handlerInput) {
    const token = 'openYouTubeToken';

    // Renderizar documento con mensaje centrado
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.RenderDocument',
        token: token,
        document: {
            type: "APL",
            version: "1.8",
            settings: {
                allowOpenURL: true // Permitir abrir URL
            },
            mainTemplate: {
                parameters: ["payload"],
                items: [
                    {
                        type: "Container",
                        width: "100vw",
                        height: "100vh",
                        justifyContent: "center",
                        alignItems: "center",
                        items: [
                            {
                                type: "Text",
                                text: "Abriendo YouTube...",
                                fontSize: "32dp",
                                fontWeight: "bold",
                                color: "white",
                                textAlign: "center"
                            }
                        ]
                    }
                ]
            }
        }
    });

    // Ejecutar OpenURL sobre el mismo token
    handlerInput.responseBuilder.addDirective({
        type: 'Alexa.Presentation.APL.ExecuteCommands',
        token: token,
        commands: [
            {
                type: 'OpenURL',
                source: 'https://www.youtube.com/watch?v=OP9w1b1-B4g&ab_channel=MarianaQuevedo%7CFisioterapiaQuer%C3%A9taro'
            }
        ]
    });

    // Mensaje por voz
    return handlerInput.responseBuilder
        .speak("Abriendo YouTube")
        .getResponse();
}


const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Hola, estoy mostrando un texto en pantalla usando APL.';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  }

};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        
        // Respondemos con un mensaje genérico
        const speakOutput = 'Lo siento, no entendí lo que dijiste. Por favor, inténtalo de nuevo o di "ayuda".';
        const session = handlerInput.attributesManager.getSessionAttributes();
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        // Redirigimos a la pantalla correspondiente
        if (session.enChat) {
            return contenidoPaginaChat(handlerInput);
        } else {
            if (session.enSatisfaccion) {
                return cuestionarioSatisfaccion(handlerInput);
            } else if (session.enUso) {
                return cuestionarioUso(handlerInput);
            } else if (session.enNuevaTarea) {
                return contenidoPaginaNuevaTarea(handlerInput);
            } else if (session.enMisTareas) { 
                return contenidoPaginaTarea(handlerInput);
            } else if (session.esperandoTarea) {
                return contenidoPaginaCompletitudTareas(handlerInput);
            } 
        
            // El usuario ha dicho algo incoherente
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt(speakOutput)
                .getResponse();
                
        } 
    }
};

/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};

/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `No se ha podido lanzar el intent ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Lo siento, hay un error. Por favor prueba de nuevo.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
 exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        APLUserEventHandler,
        PaginaIntentHandler,
        AvatarSelectionIntentHandler,
        ColorSequenceInitIntentHandler,
        ColorSequenceIntentHandler,
        LaunchRequestHandler,
        PaginaNuevaTareaHoraIntentHandler,
        PaginaNuevaTareaNombreIntentHandler,
        PaginaNuevaTareaDuracionIntentHandler,
        PaginaNuevaTareaNumeroIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();