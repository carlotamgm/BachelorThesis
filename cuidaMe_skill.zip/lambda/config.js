// config.js
const OPENAI_API_KEY = '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';

module.exports = { OPENAI_API_KEY };