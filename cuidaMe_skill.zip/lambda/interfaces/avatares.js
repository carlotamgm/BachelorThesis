const Avatar = {
  type: 'APL',
  version: '1.8',
  mainTemplate: {
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        paddingLeft: "20dp",
        paddingRight: "20dp",
        items: [
          {
            type: 'Text',
            text: "¿Quién quieres que te acompañe hoy: Marcos o Carlota?",
            fontSize: '50px',
            color: 'white',
            paddingBottom: '20px',
            textAlign: 'center'
          },
          {
            type: 'Container',
            direction: 'row',
            justifyContent: 'space-around',
            spacing: '40px',
            items: [
                
              {
                type: 'Container',
                direction: 'column',
                spacing: '20px',
                items: [
                    // Botón avatar1
                {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: [
                          "avatar",
                          "1"
                          ]
                    },
                    item: {
                      type: 'Image',
                        source: 'https://avatarok.s3.eu-west-3.amazonaws.com/enfermerO.png',
                        width: '400px',
                        height: '400px'
                    }
                },
                {
                    type: "Text",
                    text: "Marcos",
                    fontSize: '60px',
                    color: 'white',
                    textAlign: 'center'
                }
                ]
              },
              {
                type: 'Container',
                direction: 'column',
                spacing: '20px',
                items: [
                  // Botón avatar2
                {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: [
                          "avatar",
                          "2"
                          ]
                    },
                    item: {
                      type: 'Image',
                        source: 'https://avatarok.s3.eu-west-3.amazonaws.com/enfermerA.png',
                        width: '400px',
                        height: '400px'
                    }
                },
                {
                    type: "Text",
                    text: "Carlota",
                    fontSize: '60px',
                    color: 'white',
                    textAlign: 'center'
                }
                ]
              }
            ]
          }
        ]
      }
      
    ]
  }
  
};

module.exports = { Avatar };
