const Realizacion = {
    "type": "APL",
    "version": "2023.3",
    "mainTemplate": {
        "parameters": [
            "payload"
        ],
        "items": [
            {
                "type": "Container",
                "width": "100%",
                "height": "100%",
                "direction": "column",
                "justifyContent": "center",
                "alignItems": "center",
                "items": [
                    {
                        "type": "Text",
                        "text": "${payload.documentData.nombre}",
                        "color": "pink",
                        "fontSize": "42dp",
                        "fontWeight": "bold",
                        "textAlign": "center",
                        "paddingBottom": "20dp"
                    },
                    {
                        "type": "Text",
                        "text": "${payload.documentData.title}",
                        "fontSize": "28dp",
                        "textAlign": "center",
                        "paddingBottom": "40dp"
                    },
                    {
                        "type": "Container",
                        "direction": "row",
                        "justifyContent": "space-around",
                        "width": "100%",
                        "items": [
                            {
                                "type": "TouchWrapper",
                                "width": "40%",
                                "onPress": {
                                    "type": "SendEvent",
                                    "arguments": ["tareaRealizada", "sí"]
                                },
                                "item": {
                                    "type": "Frame",
                                    "backgroundColor": "green",
                                    "width": "100%",
                                    "height": "60dp",
                                    "justifyContent": "center",
                                    "alignItems": "center",
                                    "borderRadius": "30dp",
                                    "item": {
                                        "type": "Text",
                                        "text": "SÍ",
                                        "textAlign": "center",
                                         "width": "100%" ,
                                        "color": "white",
                                        "fontSize": "28dp",
                                        "fontWeight": "bold"
                                    }
                                }
                            },
                            {
                                "type": "TouchWrapper",
                                "width": "40%",
                                "onPress": {
                                    "type": "SendEvent",
                                    "arguments": ["tareaRealizada", "no"]
                                },
                                "item": {
                                    "type": "Frame",
                                    "backgroundColor": "red",
                                    "width": "100%",
                                    "height": "60dp",
                                    "justifyContent": "center",
                                    "alignItems": "center",
                                    "textAlign": "center",
                                    "borderRadius": "30dp",
                                    "item": {
                                        "type": "Text",
                                        "text": "NO",
                                        "textAlign": "center",
                                         "width": "100%" ,
                                        "color": "white",
                                        "fontSize": "28dp",
                                        "fontWeight": "bold"
                                    }
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    }
};

module.exports = { Realizacion };