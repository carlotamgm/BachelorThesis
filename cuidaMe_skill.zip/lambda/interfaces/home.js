/* Home page interface */

const HomePage = {
  type: "APL",
  version: "1.7",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        paddingLeft: "20dp",
        paddingRight: "20dp",
        items: [
            
          // Header
          {
            type: "Container",
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingTop: "20dp",
            height: "10vh",
            items: [
                // Botón marcha atrás
                {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: ["volverDeHome"]
                    },
                    item: {
                      type: "Text",
                      fontFamily: "Amazon Ember Display",
                      text: "← Atrás",
                      color: "white",
                      textDecoration: "underline",
                      fontSize: "26dp",
                      fontWeight: "500"
                    }
                }
            ]
          },

          // Subtítulo
          {
            type: "Text",
            fontFamily: "Amazon Ember Display",
            text: "¿Qué quieres hacer?",
            fontSize: "8vh",
            fontWeight: "bold",
            color: "#00FFFF",
            paddingTop: "10dp",
            textAlign: "center",
            textAlignHorizontal: "center"
          },

          // Opciones
          {
            type: "Container",
            direction: "column",
            spacing: "8vh", 
            alignItems: "center",
            grow: 1,
            paddingTop: "30dp",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["chat"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "💬 HABLAR CON EL ASISTENTE ",
                  fontSize: "7vh",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["calendario"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "📅 VER CALENDARIO DE TAREAS ",
                  fontSize: "7vh",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["cuestionarios"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "❓REALIZAR CUESTIONARIO  ",
                  fontSize: "7vh",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["resumen"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "💪 VER MI PROGRESO ",
                  fontSize: "7vh",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                }
              }
              
            ]
          }
        ]
      }
    ]
  }
};


module.exports = { HomePage };
