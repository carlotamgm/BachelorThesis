const Resumen = {
  type: "APL",
  version: "1.7",
  mainTemplate: {
    parameters: [],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        paddingLeft: "20dp",
        paddingRight: "20dp",
        items: [
          {
            type: "Container",
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingTop: "20dp",
            height: "10vh",
            items: [
            // Botón marcha atrás
            {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["volverDeResumen"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "← Atrás",
                  color: "white",
                  textDecoration: "underline",
                  fontSize: "26dp",
                  fontWeight: "500"
                }
            }
            ]
          },

          // Subtítulo
          {
            type: "Text",
            fontFamily: "Amazon Ember Display",
            text: "¿Qué resultados quieres ver?",
            fontSize: "8vh",
            fontWeight: "bold",
            color: "#00FFFF",
            paddingTop: "10dp",
            textAlign: "center",
            textAlignHorizontal: "center"
          },

          // Opciones
          {
            type: "Container",
            direction: "column",
            spacing: "20dp",
            alignItems: "center",
            grow: 1,
            paddingTop: "30dp",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["tareasCompletadas"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "MIS TAREAS COMPLETADAS ✅",
                  fontSize: "48dp",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["satisfaccion"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "MI SATISFACCIÓN 😊",
                  fontSize: "48dp",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["uso"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "MI HABILIDAD CON LA APP 💡",
                  fontSize: "48dp",
                  width: "80vw",
                  height: "10vh",
                  textAlign: "center",
                  color: "#ffffff",
                  backgroundColor: "#5A7D9A",
                  borderRadius: "10dp"
                }
                
              }
            ]
          }
        ]
      }
    ]
  }
};


module.exports = { Resumen };
