const CompletitudTareas = {
    "type": "APL",
    "version": "1.8",
    "theme": "dark",
    "mainTemplate": {
        "parameters": ["payload"],
        "items": [
            {
                "type": "Container",
                "justifyContent": "center",
                "alignItems": "center",
                "direction": "column",
                "items": [
                    /* Botón marcha atrás */
                    {
                        "type": "TouchWrapper",
                        "onPress": {
                            "type": "SendEvent",
                            "arguments": ["volverDeCompletitudTareas"]
                        },
                        "item": {
                            "type": "Text",
                            "fontFamily": "Amazon Ember Display",
                            "text": "← Atrás",
                            "color": "white",
                            "textDecoration": "underline",
                            "fontSize": "26dp",
                            "fontWeight": "500"
                        }
                    },
                    {
                        "type": "Text",
                        "fontFamily": "Amazon Ember Display",
                        "text": "${payload.documentData.title}",
                        "fontSize": "32dp",
                        "fontWeight": "bold",
                        "color": "white",
                        "paddingBottom": "32dp"
                    }
                ]
            }
        ]
    }
};

module.exports = { CompletitudTareas };