const Cuidador = {
  type: "APL",
  version: "1.7",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        items: [
          // Título "quién eres"
          {
            type: "Container",
            width: "100vw",
            paddingTop: "6vh",
            alignItems: "center",
            justifyContent: "flex-start",
            items: [
              {
                type: "Text",
                text: "¿Quién eres?",
                fontSize: "8vh",
                fontWeight: "bold",
                color: "pink",
                fontFamily: "Amazon Ember Display",
                textAlign: "center"
              }
            ]
          },
          // Contenedor central para los botones
          {
            type: "Container",
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: [
              { translateX: "-50%" },
              { translateY: "-50%" }
            ],
            direction: "column",
            spacing: "8vh", // Aumentado de 20dp a 8vh para mayor separación
            alignItems: "center",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["usuario"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "👴🏼  USUARIO",
                  width: "60vw", 
                  height: "12vh",
                  backgroundColor: "#444",
                  color: "white",
                  fontSize: "10vh", 
                  fontWeight: "bold",
                  textAlign: "center",
                  textAlignVertical: "center"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["cuidador"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "👨🏼‍⚕️ CUIDADOR",
                  width: "60vw",
                  height: "12vh",
                  backgroundColor: "#444",
                  color: "white",
                  fontSize: "10vh", 
                  fontWeight: "bold",
                  textAlign: "center",
                  textAlignVertical: "center"
                }
              }
            ]
          }
        ]
      }
    ]
  }
};
module.exports = { Cuidador };