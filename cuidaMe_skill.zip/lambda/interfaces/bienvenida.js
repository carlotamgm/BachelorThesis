// Bienvenida.js - Versión para pantalla grande de Alexa Show
const Bienvenida = {
  type: "APL",
  version: "1.8",
  theme: "dark",
  mainTemplate: {
    parameters: ["payload"],
    items: [
        
      {
        type: "Container",
        width: "100%",
        height: "100%",
        direction: "column",
        alignItems: "center",
        justifyContent: "center",
        items: [
          {
            type: "Text",
            text: "${payload.documentData.title}",
            fontFamily: "Amazon Ember Display",
            fontSize: "48dp",        // Aumentado de 24dp a 48dp
            fontWeight: "bold",
            color: "white",
            textAlign: "center",
            paddingBottom: "40dp"    // Aumentado de 20dp a 40dp
          },
          {
            type: "Image",
            source: "${payload.documentData.imagen}",
            width: "80vw",           // Ajustado para pantalla grande
            height: "50vh",          // Aumentado el espacio para la imagen
            scale: "best-fit",
            paddingBottom: "40dp"    // Aumentado de 20dp a 40dp
          },
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["empezar"]
            },
            item: {
              type: "Frame",
              backgroundColor: "#007aff",
              width: "auto",
              height: "auto",
              paddingLeft: "48dp",    // Aumentado de 24dp a 48dp
              paddingRight: "48dp",   // Aumentado de 24dp a 48dp
              paddingTop: "24dp",     // Aumentado de 12dp a 24dp
              paddingBottom: "24dp",  // Aumentado de 12dp a 24dp
              borderRadius: "16dp",   // Aumentado de 8dp a 16dp
              alignItems: "center",
              justifyContent: "center",
              item: {
                type: "Text",
                text: "EMPEZAR",
                fontSize: "36dp",    // Aumentado de 20dp a 36dp
                fontWeight: "bold",
                color: "white",
                textAlign: "center"
              }
            }
          }
        ]
      }
    ]
  }
};
module.exports = { Bienvenida };