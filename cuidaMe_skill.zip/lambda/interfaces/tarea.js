const Tarea = {
  "type": "APL",
  "version": "1.8",
  "theme": "dark",
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "width": "100vw",
        "height": "100vh",
        "alignItems": "center",
        "justifyContent": "start",
        "paddingTop": "3vh",
        "items": [
          // Botón Atrás
          {
            "type": "TouchWrapper",
            "onPress": {
              "type": "SendEvent",
              "arguments": ["volverDeTarea"]
            },
            "item": {
              "type": "Text",
              "text": "← Atrás",
              "fontSize": "26dp",
              "color": "white",
              "fontWeight": "500",
              "textDecoration": "underline",
              "paddingLeft": "20dp"
            },
            "alignSelf": "start"
          },

          // Título de la tarea
          {
            "type": "Text",
            "text": "${payload.documentData.nombre}",
            "fontSize": "34dp",
            "fontWeight": "bold",
            "color": "pink",
            "textAlign": "center",
            "paddingTop": "10dp",
            "paddingBottom": "20dp"
          },

          // Hora y duración
          {
            "type": "Text",
            "textType": "rich",
            "text": "<span color='#00aced'>🕒 Hora de realización:</span> <span color='white'>${payload.documentData.hora}</span>",
            "fontSize": "26dp",
            "textAlign": "center",
            "paddingBottom": "8dp"
          },
          {
            "type": "Text",
            "textType": "rich",
            "text": "<span color='#00aced'>⏳ Duración:</span> <span color='white'>${payload.documentData.duracion}</span>",
            "fontSize": "26dp",
            "textAlign": "center",
            "paddingBottom": "16dp"
          },

          // Días
          {
          "type": "Text",
          "text": "📅 Días completados:",
              "fontSize": "26dp",
              "color": "#00FF00",
              "paddingTop": "16dp",
              "paddingBottom": "8dp"
            },
            {
              "type": "Sequence",
              "scrollDirection": "vertical",
              "height": "auto",
              "maxHeight": "20vh",
              "data": "${payload.documentData.completados ? payload.documentData.completados : []}",
              "items": [
                {
                  "type": "Container",
                  "direction": "row",
                  "justifyContent": "center",
                  "alignItems": "center",
                  "width": "100%",
                  "paddingBottom": "8dp",
                  "items": [
                    {
                      "type": "Text",
                        "textAlign": "center",
                      "text": "✅ ${data}",
                      "fontSize": "24dp",
                      "color": "#00FF00",
                      "width": "100%"
                    }
                  ]
                }
              ]
            },
            {
              "type": "Text",
              "text": "📅 Días pendientes:",
              "fontSize": "26dp",
              "color": "#FF4500",
              "paddingTop": "16dp",
              "paddingBottom": "8dp"
            },
            {
              "type": "Sequence",
              "scrollDirection": "vertical",
              "height": "auto",
              "maxHeight": "20vh",
              "data": "${payload.documentData.noCompletados ? payload.documentData.noCompletados : []}",
              "items": [
                {
                  "type": "Container",
                  "justifyContent": "center",
                  "alignItems": "center",
                  "direction": "row",
                  "width": "100%",
                  "paddingBottom": "8dp",
                  "items": [
                    {
                      "type": "Text",
                        "textAlign": "center",
                      "text": "❌ ${data}",
                      "fontSize": "24dp",
                      "color": "#FF4500",
                      "width": "100%"
                    }
                  ]
                }
              ]
            },
          // Descripción
          {
            "type": "Text",
            "text": "📝 Pasos de la tarea:",
            "fontSize": "26dp",
            "color": "#ADFF2F",
            "paddingTop": "24dp",
            "paddingBottom": "12dp"
          },
          {
            "type": "Sequence",
            "scrollDirection": "vertical",
            "height": "30vh",
            "data": "${payload.documentData.pasos}",
            "items": [
              {
                "type": "Frame",
                "borderColor": "#FFFFFF",
                "borderWidth": "2dp",
                "backgroundColor": "#333333",
                "cornerRadius": "12dp",
                "padding": "12dp",
                "marginBottom": "10dp",
                "items": [
                  {
                    "type": "Text",
                    "text": "Paso ${index + 1}: ${data}",
                    "fontSize": "24dp",
                    "color": "#FFFFFF",
                    "textAlign": "center"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { Tarea };
