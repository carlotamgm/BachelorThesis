const Fijacion = {
    type: "APL",
    version: "1.8",
    mainTemplate: {
        parameters: ["payload"],
        items: [
            {
                type: "Container",
                width: "100vw",
                height: "100vh",
                justifyContent: "center",
                alignItems: "center",
                items: [
                    {
                        type: "Container",
                        direction: "column",
                        width: "80%",
                        alignItems: "center",
                        spacing: 16,
                        items: [
                            {
                                type: "Text",
                                text: "🧠 Recuerdo inmediato",
                                fontSize: "8vh",
                                fontWeight: "bold",
                                color: "pink",
                                textAlign: "center",
                                paddingBottom: "20dp"
                            },
                            {
                                type: "Text",
                                text: "Recuerda:",
                                fontSize: "30dp",
                                color: "#00FFFF",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "Peseta - Caballo - Manzana",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "Ahora repite las palabras",
                                fontSize: "30dp",
                                color: "#00FFFF",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "TouchWrapper",
                                onPress: {
                                    type: "SendEvent",
                                    arguments: ["cerrarCuestionario"]
                                },
                                item: {
                                    type: "Frame",
                                    backgroundColor: "red",
                                    borderRadius: "12dp",
                                    paddingLeft: "32dp",
                                    paddingRight: "32dp",
                                    paddingTop: "16dp",
                                    paddingBottom: "16dp",
                                    item: {
                                        type: "Text",
                                        text: "CERRAR CUESTIONARIO",
                                        fontSize: "40dp",
                                        fontWeight: "bold",
                                        color: "white",
                                        textAlign: "center"
                                    }
                                },
                                 paddingBottom: "6vh", // 👈 espacio vertical adicional
                                
                                alignSelf: "center",
                                paddingTop: "20dp"
                            },
                            {
                                type: "Text",
                                text: "¡Muchas gracias por tus respuestas! 📧 El resultado se enviará por correo a tu cuidador. ",
                                fontSize: "30dp",
                                color: "pink",
                                wrap: true,
                                textAlign: "center"
                            }
                        ]
                    }
                ]
            }
        ]
    }
};

module.exports = { Fijacion };
