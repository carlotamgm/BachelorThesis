const Premios = {
  type: "APL",
  version: "1.8",
  theme: "dark",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        direction: "column",
        width: "100vw",
        height: "100vh",
        padding: 20,
        items: [
          // Botón "Atrás" alineado a la izquierda
          {
            type: "Container",
            width: "100%",
            alignItems: "start",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["volverDePremio"]  
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "← Atrás",
                  color: "white",
                  textDecoration: "underline",
                  fontSize: "26dp",
                  fontWeight: "500",
                  paddingBottom: "10dp"
                }
              }
            ]
          },

          // Un poco de separación bajo el botón
          { type: "Container", height: "20dp" },

          // Bloque central con título y botones
          {
            type: "Container",
            direction: "column",
            grow: 1,
            justifyContent: "center",
            alignItems: "center",
            items: [
              {
                type: "Text",
                text: "Elige tu premio:",
                fontSize: "36dp",
                fontWeight: "bold",
                color: "white",
                textAlign: "center"
              },
              // espacio vertical
              { type: "Container", height: "40dp" },

              {
                type: "Container",
                direction: "row",
                justifyContent: "center",
                alignItems: "center",
                items: [
                  /* VÍDEO */
                  {
                    type: "TouchWrapper",
                    onPress: { type: "SendEvent", arguments: ["premioVideo"] },
                    item: {
                      type: "Frame",
                      backgroundColor: "#3A8FB7",
                      borderRadius: "16dp",
                      minWidth: "160dp",
                      minHeight: "64dp",
                      paddingLeft: "24dp",
                      paddingRight: "24dp",
                      paddingTop: "18dp",
                      paddingBottom: "18dp",
                      item: {
                        type: "Text",
                        text: "VÍDEO",
                        color: "white",
                        fontSize: "28dp",
                        fontWeight: "bold",
                        textAlign: "center"
                      }
                    }
                  },

                  // espacio horizontal
                  { type: "Container", width: "60dp" },

                  /* JUEGO */
                  {
                    type: "TouchWrapper",
                    onPress: { type: "SendEvent", arguments: ["premioJuego"] },
                    item: {
                      type: "Frame",
                      backgroundColor: "#FF1493",
                      borderRadius: "16dp",
                      minWidth: "160dp",
                      minHeight: "64dp",
                      paddingLeft: "24dp",
                      paddingRight: "24dp",
                      paddingTop: "18dp",
                      paddingBottom: "18dp",
                      item: {
                        type: "Text",
                        text: "JUEGO",
                        color: "white",
                        fontSize: "28dp",
                        fontWeight: "bold",
                        textAlign: "center"
                      }
                    }
                  },

                  // espacio horizontal
                  { type: "Container", width: "60dp" },

                  /* MÚSICA */
                  {
                    type: "TouchWrapper",
                    onPress: { type: "SendEvent", arguments: ["premioMusica"] },
                    item: {
                      type: "Frame",
                      backgroundColor: "green",
                      borderRadius: "16dp",
                      minWidth: "160dp",
                      minHeight: "64dp",
                      paddingLeft: "24dp",
                      paddingRight: "24dp",
                      paddingTop: "18dp",
                      paddingBottom: "18dp",
                      item: {
                        type: "Text",
                        text: "MÚSICA",
                        color: "white",
                        fontSize: "28dp",
                        fontWeight: "bold",
                        textAlign: "center"
                      }
                    }
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { Premios };
