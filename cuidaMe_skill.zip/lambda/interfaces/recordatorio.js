const Recordatorio = {
  type: "APL",
  version: "2023.3",
  theme: "dark",
  import: [{ name: "alexa-layouts", version: "1.7.0" }],
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100%",
        height: "100%",
        backgroundColor: "#111418",          // fondo oscuro elegante
        padding: "24dp",
        direction: "column",
        items: [
          /* HEADER */
          {
            type: "Container",
            width: "100%",
            backgroundColor: "#E91E63",      // rosa fuerte con buen contraste
            borderRadius: "16dp",
            padding: "14dp",
            items: [
              {
                type: "Text",
                text: "⏰  ¡HA LLEGADO LA HORA!  ⏰",
                color: "white",
                fontSize: "28dp",
                fontWeight: "700",
                textAlign: "center"
              },
              {
                type: "Text",
                text: "Ahora ponte a: ${payload.documentData.nombre}",
                color: "white",
                fontSize: "6vh",
                fontWeight: "700",
                textAlign: "center",
                opacity: 0.9,
                paddingTop: "6dp"
              }
            ]
          },

          /* SUBTITULO */
          {
            type: "Text",
            text: "📌 PASOS A SEGUIR",
            color: "#FFB3C7",
            fontSize: "30dp",
            fontWeight: "600",
            textAlign: "center",
            paddingTop: "16dp",
            paddingBottom: "8dp"
          },

          /* LISTA DE PASOS */
          {
              "type": "Container",
               "maxHeight": "40vh", 
              "width": "100%",
              "height": "56vh",
              "backgroundColor": "#1A1F25",
              "borderRadius": "16dp",
              "padding": "8dp",
              "items": [
                {
                  "type": "Sequence",
                  "data": "${payload.documentData.pasos}",
                  "width": "100%",
                  "height": "100%",
                  "items": [
                    {
                      "type": "Text",
                      "text": "• ${index + 1}. ${data}",
                      "color": "powderblue",
                      "textAlign": "center",
                      "wrap": true,
                      "maxLines": 2,
                      "fontSize": "${payload.documentData.pasos.length <= 5 ? '30dp' : payload.documentData.pasos.length <= 8 ? '30dp' : '28dp'}",
                      "paddingVertical": "4dp",
                      "paddingHorizontal": "6dp"
                    },
                    {
                      "type": "Divider",
                      "when": "${index < payload.documentData.pasos.length - 1}",
                      "color": "#2A2F36"
                    }
                  ]
                }
              ]
            },

          /* BOTÓN CERRAR (TEXTO CENTRADO) */
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["cerrarRecordatorio"]
            },
            item: {
              type: "Frame",
              backgroundColor: "red",
              borderRadius: "12dp",
              paddingLeft: "32dp",
              paddingRight: "32dp",
              paddingTop: "16dp",
              paddingBottom: "16dp",
              item: {
                type: "Text",
                text: "CERRAR RECORDATORIO",
                fontSize: "30dp",
                fontWeight: "bold",
                color: "white",
                textAlign: "center"
              }
            },
            alignSelf: "center",
            paddingTop: "20dp"
          }
        ]
      }
    ]
  }
};

module.exports = { Recordatorio };
