const OrientacionTemporal = {
  type: "APL",
  version: "1.8",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        paddingLeft: "20dp",
        paddingRight: "20dp",
        paddingTop: "20dp",
        alignItems: "center",
        spacing: 20,
        items: [
          // 🔙 Botón marcha atrás
          {
            type: "Container",
            direction: "row",
            width: "100%",
            justifyContent: "flex-start",
            alignItems: "center",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["volverDeSecuenciaColores"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "← Atrás",
                  color: "white",
                  textDecoration: "underline",
                  fontSize: "26dp",
                  fontWeight: "500"
                }
              }
            ]
          },
          // 🧠 Título
          {
            type: "Text",
            text: "🧠 Orientación Temporal",
            fontSize: "8vh",
            fontWeight: "bold",
            color: "pink",
            textAlign: "center",
            paddingBottom: "10dp"
          },
          // Preguntas
          {
            type: "Text",
            text: "1. ¿En qué año estamos?",
            fontSize: "30dp",
            color: "white",
            wrap: true,
            textAlign: "center"
          },
          {
            type: "Text",
            text: "2. ¿En qué estación?",
            fontSize: "30dp",
            color: "white",
            wrap: true,
            textAlign: "center"
          },
          {
            type: "Text",
            text: "3. ¿En qué día (fecha)?",
            fontSize: "30dp",
            color: "white",
            wrap: true,
            textAlign: "center"
          },
          {
            type: "Text",
            text: "4. ¿En qué mes?",
            fontSize: "30dp",
            color: "white",
            wrap: true,
            textAlign: "center"
          },
          {
            type: "Text",
            text: "5. ¿En qué día de la semana?",
            fontSize: "30dp",
            color: "white",
            wrap: true,
            textAlign: "center"
          },
          // Botón siguiente
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["siguientePregunta"]
            },
            item: {
              type: "Frame",
              backgroundColor: "powderblue",
              borderRadius: "12dp",
              paddingLeft: "32dp",
              paddingRight: "32dp",
              paddingTop: "16dp",
              paddingBottom: "16dp",
              item: {
                type: "Text",
                text: "SIGUIENTE PREGUNTA",
                fontSize: "40dp",
                fontWeight: "bold",
                color: "black",
                textAlign: "center"
              }
            },
            alignSelf: "center",
            paddingTop: "20dp"
          }
        ]
      }
    ]
  }
};

module.exports = { OrientacionTemporal };
