const EliminarTarea = {
  "type": "APL",
  "version": "1.8",
  "theme": "dark",
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "items": [
          {
            "type": "TouchWrapper",
            "onPress": {
              "type": "SendEvent",
              "arguments": ["volverDeMisTareas"]
            },
            "alignSelf": "start",
            "item": {
              "type": "Text",
              "fontFamily": "Amazon Ember Display",
              "text": "← Atrás",
              "color": "white",
              "textDecoration": "underline",
              "fontSize": "26dp",
              "fontWeight": "500"
            }
          },
          {
            "type": "Video",
            "id": "videoPlayerId",
            "width": "40vw",
            "height": "40vh",
            "alignSelf": "end",
            "position": "absolute",
            "top": "2vh",
            "right": "2vw",
            "autoplay": true,
            "audioTrack": "none",
            "source": "${payload.documentData.avatarUrl}"
          },
          {
            "type": "Text",
            "text": "${payload.documentData.title}",
            "fontFamily": "Amazon Ember Display",
            "fontSize": "32dp",
            "fontWeight": "bold",
            "color": "pink",
            "paddingBottom": "16dp"
          },
          {
            "type": "Sequence",
            "scrollDirection": "vertical",
            "height": "55vh",
            "data": "${payload.documentData.tareas.length > 0 ? payload.documentData.tareas : [{}]}",
            "items": [
              {
                "type": "TouchWrapper",
                "when": "${payload.documentData.tareas.length > 0}",
                "onPress": {
                  "type": "SendEvent",
                  "arguments": [
                    "eliminarTarea",
                    "${data.nombre}"
                  ]
                },
                "item": {
                  "type": "Text",
                  "fontFamily": "Amazon Ember Display",
                  "text": "${data.nombre}",
                  "fontSize": "32dp",
                  "color": "#ffffff",
                  "padding": "12dp",
                  "backgroundColor": "#333333",
                  "borderBottomWidth": "1dp",
                  "borderColor": "#555555"
                }
              },
              {
                "type": "Text",
                "when": "${payload.documentData.tareas.length == 0}",
                "text": "No hay tareas que eliminar.",
                "fontFamily": "Amazon Ember Display",
                "fontSize": "24dp",
                "color": "#cccccc",
                "textAlign": "start",
                "paddingTop": "20dp"
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { EliminarTarea };
