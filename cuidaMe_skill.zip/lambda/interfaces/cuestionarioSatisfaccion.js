const CuestionarioSatisfaccion = {
  type: "APL",
  version: "2023.3",
  theme: "light",
  import: [
    {
      name: "alexa-layouts",
      version: "1.7.0"
    }
  ],
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        paddingLeft: "20dp",
        paddingRight: "20dp",
        items: [
          // 🔙 Botón marcha atrás en cabecera
          {
            type: "Container",
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingTop: "20dp",
            height: "10vh",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["volverDeSecuenciaColores"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "← Atrás",
                  color: "white",
                  textDecoration: "underline",
                  fontSize: "26dp",
                  fontWeight: "500"
                }
              }
            ]
          },
          // 📦 Contenido central (cuestionario)
          {
            type: "Container",
            width: "100%",
            backgroundColor: "#6A4C93",
            direction: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "40dp",
            borderRadius: "20dp",
            borderWidth: "4dp",
            borderColor: "#FFFFFF",
            items: [
              {
                type: "Text",
                text: "⭐ Valoración",
                color: "white",
                fontSize: "48dp",
                fontWeight: "bold",
                textAlign: "center",
                paddingBottom: "20dp",
                width: "100%"
              },
              {
                type: "Container",
                width: "100%",
                alignItems: "center",
                paddingBottom: "30dp",
                items: [
                  {
                    type: "Text",
                    text: "${payload.documentData.title}",
                    color: "#FFD166",
                    fontSize: "28dp",
                    textAlign: "center",
                    width: "90%",
                    style: "questionStyle"
                  }
                ]
              },
              {
                type: "Container",
                direction: "row",
                justifyContent: "space-between",
                width: "100%",
                paddingBottom: "10dp",
                items: [
                  {
                    type: "Container",
                    direction: "column",
                    alignItems: "center",
                    width: "auto",
                    items: [
                      {
                        type: "TouchWrapper",
                        onPress: {
                          type: "SendEvent",
                          arguments: ["cuestionarioSatisfaccion", "1"]
                        },
                        item: {
                          type: "Text",
                          text: "1️⃣",
                          fontSize: "48dp",
                          color: "#F44336",
                          textAlign: "center"
                        }
                      },
                      {
                        type: "Text",
                        text: "No me gusta",
                        color: "rgba(255,255,255,0.8)",
                        fontSize: "22dp",
                        textAlign: "center",
                        paddingTop: "5dp"
                      }
                    ]
                  },
                  {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: ["cuestionarioSatisfaccion", "2"]
                    },
                    item: {
                      type: "Text",
                      text: "2️⃣",
                      fontSize: "48dp",
                      color: "#FF9800",
                      textAlign: "center"
                    }
                  },
                  {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: ["cuestionarioSatisfaccion", "3"]
                    },
                    item: {
                      type: "Text",
                      text: "3️⃣",
                      fontSize: "48dp",
                      color: "#FFEB3B",
                      textAlign: "center"
                    }
                  },
                  {
                    type: "TouchWrapper",
                    onPress: {
                      type: "SendEvent",
                      arguments: ["cuestionarioSatisfaccion", "4"]
                    },
                    item: {
                      type: "Text",
                      text: "4️⃣",
                      fontSize: "48dp",
                      color: "#8BC34A",
                      textAlign: "center"
                    }
                  },
                  {
                    type: "Container",
                    direction: "column",
                    alignItems: "center",
                    width: "auto",
                    items: [
                      {
                        type: "TouchWrapper",
                        onPress: {
                          type: "SendEvent",
                          arguments: ["cuestionarioSatisfaccion", "5"]
                        },
                        item: {
                          type: "Text",
                          text: "5️⃣",
                          fontSize: "48dp",
                          color: "#4CAF50",
                          textAlign: "center"
                        }
                      },
                      {
                        type: "Text",
                        text: "Me encanta",
                        color: "rgba(255,255,255,0.8)",
                        fontSize: "22dp",
                        textAlign: "center",
                        paddingTop: "5dp"
                      }
                    ]
                  }
                ]
              },
              {
                type: "Text",
                text: "ℹ️ Toca el número que mejor represente tu opinión",
                color: "rgba(255,255,255,0.7)",
                fontSize: "30dp",
                paddingTop: "30dp",
                fontStyle: "italic",
                textAlign: "center",
                width: "100%"
              }
            ]
          }
        ]
      }
    ]
  },
  styles: {
    questionStyle: {
      fontFamily: "Amazon Ember",
      textAlign: "center",
      fontWeight: "bold"
    }
  }
};
module.exports = { CuestionarioSatisfaccion };
