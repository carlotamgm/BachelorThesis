const SecuenciaColores = 
    {
    "type": "APL",
    "version": "2023.1",
    "license": "Copyright 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.\nSPDX-License-Identifier: LicenseRef-.amazon.com.-AmznSL-1.0\nLicensed under the Amazon Software License  http://aws.amazon.com/asl/",
    "theme": "light",
    "import": [
        {
            "name": "alexa-viewport-profiles",
            "version": "1.0.0"
        },
        {
            "name": "alexa-layouts",
            "version": "1.7.0"
        },
        {
            "name": "alexa-styles",
            "version": "1.0.0"
        }
    ],
    "resources": [
        {
            "description": "Stock color for the light theme",
            "when": "${viewport.theme == 'light'}",
            "colors": {
                "colorTextPrimary": "#151920"
            }
        },
        {
            "description": "Stock color for the dark theme",
            "when": "${viewport.theme == 'dark'}",
            "colors": {
                "colorTextPrimary": "#f0f1ef"
            }
        },
        {
            "description": "Background image for the light theme",
            "when": "${viewport.theme == 'light'}",
            "strings": {
                "background": "https://media.istockphoto.com/id/928906478/es/vector/mol%C3%A9cula-de-estructura-y-comunicaci%C3%B3n-adn-%C3%A1tomo-las-neuronas-fondo-cient%C3%ADfico-mol%C3%A9cula-para.jpg?s=612x612&w=0&k=20&c=ThmWidWRg8gFaNaWOBLx7AcbCEUPUVnfL3csYQp3iFw="
            }
        },
        {
            "description": "Background image for the dark theme",
            "when": "${viewport.theme == 'dark'}",
            "strings": {
                "background": "https://img.freepik.com/fotos-premium/neurona-motora-azul-celula-nerviosa-fondo-oscuro-3d-rendering_648796-1300.jpg"
            }
        },
        {
            "description": "Standard font sizes",
            "dimensions": {
                "textSizeBody": "${payload.launchData.properties.textSizeBody}",
                "textSizePrimary": "${payload.launchData.properties.textSizePrimary}",
                "textSizeSecondary": "${payload.launchData.properties.textSizeSecondary}",
                "textSizeDetails": "${payload.launchData.properties.textSizeDetails}",
                "textSizeSecondaryHint": "${payload.launchData.properties.textSizeSecondaryHint}"
            }
        },
        {
            "description": "Common margins and padding",
            "dimensions": {
                "marginTop": 40,
                "marginLeft": 60,
                "marginRight": 60,
                "marginBottom": 40
            }
        },
        {
            "description": "Image assets",
            "strings": {
                "skillIcon": "https://cdn.pixabay.com/photo/2021/06/30/09/00/brain-6376269_1280.png"
            }
        }
    ],
    "layouts": {
        "LaunchScreen": {
            "description": "A basic launch screen with a text and logo",
            "parameters": [
                {
                    "name": "mainText",
                    "type": "string"
                },
                {
                    "name": "game",
                    "type": "string"
                }
            ],
            "items": [
                {
                    "type": "Container",
                    "width": "100%",
                    "height": "100%",
                    "justifyContent": "center",
                    "alignItems": "center",
                    "item": [
                        {
                            "type": "Image",
                            "source": "${game}",
                            "width": "30vw",
                            "height": "30vw",
                            "scale": "best-fill"
                        },
                        {
                            "type": "Text",
                            "when": "${viewport.theme == 'light'}",
                            "text": "${mainText}",
                            "style": "textStyleDisplay4",
                            "paddingTop": "50dp",
                            "color": "#151920"
                        },
                        {
                            "type": "Text",
                            "when": "${viewport.theme == 'dark'}",
                            "text": "${mainText}",
                            "style": "textStyleDisplay4",
                            "paddingTop": "50dp",
                            "color": "#f0f1ef"
                        }
                    ]
                }
            ]
        }
    },
    "mainTemplate": {
        "parameters": [
            "payload"
        ],
        "item": [
            {
                "type": "Container",
                "direction": "column",
                "items": [
                    {
                        "type": "Image",
                        "source": "@background",
                        "width": "100vw",
                        "height": "100vw",
                        "scale": "best-fill"
                    },
                    {
                        "type": "Container",
                        "position": "absolute",
                        "width": "100%",
                        "height": "100%",
                        "direction": "column",
                        "items": [
                            // Botón Atrás - NUEVO
                            {
                                "type": "Container",
                                "position": "absolute",
                                "top": "10dp",
                                "left": "10dp",
                                "zIndex": 100,
                                "item": {
                                    "type": "TouchWrapper",
                                    "onPress": {
                                        "type": "SendEvent",
                                        "arguments": ["volverDeSecuenciaColores"]
                                    },
                                    "item": {
                                        "type": "Text",
                                        "text": "← Atrás",
                                        "fontFamily": "Amazon Ember Display",
                                        "fontSize": "26dp",
                                        "color": "black",
                                        "textDecoration": "underline",
                                        "padding": "10dp"
                                    }
                                }
                            },
                            {
                                "headerTitle": "${payload.launchData.properties.headerTitle}",
                                "type": "AlexaHeader",
                                "paddingTop": "50dp",
                                "when": "${viewport.theme == 'light'}",
                                "color": "#151920"
                            },
                            {
                                "headerTitle": "${payload.launchData.properties.headerTitle}",
                                "type": "AlexaHeader",
                                "when": "${viewport.theme == 'dark'}",
                                "color": "#151920"
                            },
                            {
                                "type": "Container",
                                "width": "100vw",
                                "height": "70vh",
                                "position": "relative",
                                "alignItems": "center",
                                "justifyContent": "center",
                                "direction": "column",
                                "items": [
                                    {
                                        "type": "LaunchScreen",
                                        "mainText": "${payload.launchData.properties.mainText}",
                                        "game": "${payload.launchData.properties.game}"
                                    }
                                ]
                            },
                            {
                                "footerHint": "${payload.launchData.properties.hintString}",
                                "type": "AlexaFooter"
                            }
                        ]
                    }
                ]
            }
        ]
    }
}
module.exports = { SecuenciaColores };