const Chat = {
  "type": "APL",
  "version": "1.8",
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "alignItems": "center",
        "justifyContent": "spaceBetween",
        "height": "100vh",
        "width": "100vw",
        "backgroundColor": "#1a1a1a",
        "items": [
          // Botón marcha atrás (arriba del todo)
          {
            "type": "TouchWrapper",
            "onPress": {
              "type": "SendEvent",
              "arguments": ["volverDeChat"]
            },
             "alignSelf": "start",  
            "item": {
              "type": "Text",
              "text": "← Atrás",
              "fontFamily": "Amazon Ember Display",
              "fontSize": "26dp",
              "color": "white",
              "textDecoration": "underline",
              "paddingTop": "10dp",
              "paddingBottom": "10dp"
            }
          },

          // Chat  (solo visible cuando hay mensajes)
          {
            "type": "Sequence",
            "when": "${payload.documentData.conversationMessages && payload.documentData.conversationMessages.length > 0}",
            "id": "chatHistorySequence",
            "grow": 1,
            "width": "90vw",
            "height": "100%",
            "spacing": "10dp",
            "data": "${payload.documentData.conversationMessages}",
            "alignSelf": "center",
            "wrap": true,
            "scrollDirection": "vertical",
            "items": [
              {
                "type": "Container",
                "width": "100%",
                "alignItems": "${data.role == 'user' ? 'end' : 'start'}",
                "items": [
                  {
                    "type": "Frame",
                    "backgroundColor": "${data.role == 'user' ? '#007ACC' : '#006400'}",
                    "padding": "16dp",
                    "borderRadius": "24dp",
                    "maxWidth": "70vw",
                    "borderWidth": "1dp",
                    "borderColor": "${data.role == 'user' ? '#005a99' : '#004d00'}",
                    "item": {
                      "type": "Text",
                      "text": "${data.content}",
                      "fontFamily": "Amazon Ember Display",
                      "fontSize": "24dp",
                      "color": "#FFFFFF",
                      "wrap": true
                    }
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { Chat };
