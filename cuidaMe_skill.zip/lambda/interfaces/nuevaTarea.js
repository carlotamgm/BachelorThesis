/* Nueva Tarea interface */

const NuevaTarea = {
  "type": "APL",
  "version": "1.8",
  "theme": "dark",
  "mainTemplate": {
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "alignItems": "center",
        "paddingTop": 40,
        "items": [
          // Botón marcha atrás
          {
            "type": "TouchWrapper",
            "onPress": [
              {
                "type": "SendEvent",
                "arguments": ["volverDeNuevaTarea"]
              }
            ],
            "alignSelf": "start",
            "item": {
              "type": "Text",
              "fontFamily": "Amazon Ember Display",
              "text": "← Atrás",
              "color": "white",
              "textDecoration": "underline",
              "fontSize": "26dp",
              "fontWeight": "500"
            }
          },
          {
            "type": "Text",
            "text": "📝 Nueva Tarea",
            "style": "textStyleTitle",
            "paddingBottom": 30
          },
          {
            "type": "Frame",
            "borderWidth": 2,
            "borderColor": "#00D0FF",
            "padding": 20,
            "backgroundColor": "#1A1A1A",
            "items": [
              {
                "type": "Container",
                "direction": "column",
                "spacing": 20,
                "items": [
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "🧾 Nombre", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "📋 Descripción", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "📆 Días", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "🕒 Hora", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "🔄 Periodo de repetición", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "🔢 Veces de repetición", "style": "textStyleItem" }
                    ]
                  },
                  {
                    "type": "Frame",
                    "borderColor": "#ffffff",
                    "borderWidth": 1,
                    "padding": 12,
                    "backgroundColor": "#333333",
                    "items": [
                      { "type": "Text", "fontFamily": "Amazon Ember Display", "text": "⏳ Duración", "style": "textStyleItem" }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  "styles": {
    "textStyleTitle": {
      "values": [
        {
          "fontSize": "34dp",
          "fontWeight": "bold",
          "color": "white",
          "textAlign": "center"
        }
      ]
    },
    "textStyleItem": {
      "values": [
        {
          "fontSize": "24dp",
          "color": "#FFFFFF"
        }
      ]
    }
  }
}

module.exports = { NuevaTarea };