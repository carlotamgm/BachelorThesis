const Uso = {
  type: "APL",
  version: "1.7",
  theme: "light",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        direction: "column",
        width: "100%",
        height: "100%",
        padding: "20dp",
        items: [
          // Botón marcha atrás
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["volverDeUso"]
            },
            item: {
              type: "Text",
              fontFamily: "Amazon Ember Display",
              text: "← Atrás",
              color: "white",
              textDecoration: "underline",
              fontSize: "26dp",
              fontWeight: "500"
            }
          },
          {
            type: "Text",
            fontFamily: "Amazon Ember Display",
            text: "Valoración de Facilidad de Uso",
            fontSize: "28dp",
            fontWeight: "bold",
            textAlign: "center",
            color: "black",
            wrap: true,
            paddingBottom: "20dp"
          },
          {
            type: "Container",
            direction: "column",
            alignItems: "center",
            items: [
              {
                type: "Image",
                source: "${payload.documentData.imagen}",
                width: "200dp",
                height: "200dp",
                scale: "best-fit",
                paddingBottom: "20dp"
              },
              {
                type: "Text",
                text: "${payload.documentData.feedback}",
                fontFamily: "Amazon Ember Display",
                fontSize: "28dp",
                textAlign: "center",
                color: "${payload.documentData.color ? payload.documentData.color : 'black'}",
                wrap: true,
                paddingTop: "20dp",
                fontWeight: "bold"
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { Uso };
