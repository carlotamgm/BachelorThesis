const Tareas = {
  type: "APL",
  version: "1.7",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        items: [
          // Botón Atrás
          {
            type: "TouchWrapper",
            position: "absolute",
            top: "2vh",
            left: "2vw",
            onPress: {
              type: "SendEvent",
              arguments: ["volverDeTareas"]
            },
            item: {
              type: "Text",
              text: "← Atrás",
              color: "white",
              fontSize: "26dp",
              fontWeight: "bold"
            }
          },
          // Título "Tareas"
          {
            type: "Container",
            width: "100vw",
            paddingTop: "6vh",
            alignItems: "center",
            justifyContent: "flex-start",
            items: [
              {
                type: "Text",
                text: "Tareas",
                fontSize: "6vh",
                fontWeight: "bold",
                color: "pink",
                fontFamily: "Amazon Ember Display",
                textAlign: "center"
              }
            ]
          },
          // Contenedor central para los botones
          {
            type: "Container",
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: [
              { translateX: "-50%" },
              { translateY: "-50%" }
            ],
            direction: "column",
            spacing: "20dp",
            alignItems: "center",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["misTareas"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "VER MIS TAREAS 📋",
                  width: "60vw",
                  height: "12vh",
                  backgroundColor: "#444",
                  color: "white",
                  fontSize: "7vh",
                  fontWeight: "bold",
                  textAlign: "center",
                  textAlignVertical: "center"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["nuevaTarea"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "CREAR TAREA ➕",
                  width: "60vw",
                  height: "12vh",
                  backgroundColor: "#444",
                  color: "white",
                  fontSize: "7vh",
                  fontWeight: "bold",
                  textAlign: "center",
                  textAlignVertical: "center"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              },
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["eliminarTarea"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "ELIMINAR TAREA 🗑️",
                  width: "60vw",
                  height: "12vh",
                  backgroundColor: "#444",
                  color: "white",
                  fontSize: "7vh",
                  fontWeight: "bold",
                  textAlign: "center",
                  textAlignVertical: "center"
                },
                paddingBottom: "6vh" // 👈 espacio vertical adicional
              }
            ]
          },
          // Video avatar
          {
            type: "Video",
            id: "videoPlayerId",
            position: "absolute",
            top: "1vh",
            right: "1vw",
            width: "30vw",
            height: "30vh",
            autoplay: true,
            audioTrack: "none",
            source: "${payload.documentData.avatarUrl}"
          }
        ]
      }
    ]
  }
};

module.exports = { Tareas };