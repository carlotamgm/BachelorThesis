const CuestionarioUso = 
{
  "type": "APL",
  "version": "2023.3",
  "theme": "light",
  "import": [
    {
      "name": "alexa-layouts",
      "version": "1.7.0"
    }
  ],
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "width": "100vw",
        "height": "100vh",
        "backgroundColor": "#4A6FA5",
        "direction": "column",
        "alignItems": "center",
        "justifyContent": "center",
        "padding": "40dp",
        "items": [
            
            // 🔙 Botón marcha atrás en cabecera
          {
            type: "Container",
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingTop: "20dp",
            height: "10vh",
            items: [
              {
                type: "TouchWrapper",
                onPress: {
                  type: "SendEvent",
                  arguments: ["volverDeSecuenciaColores"]
                },
                item: {
                  type: "Text",
                  fontFamily: "Amazon Ember Display",
                  text: "← Atrás",
                  color: "white",
                  textDecoration: "underline",
                  fontSize: "26dp",
                  fontWeight: "500"
                }
              }
            ]
          },
          {
            "type": "Container",
            "width": "auto",
            "maxWidth": "600dp",
            "borderRadius": "20dp",
            "borderWidth": "4dp",
            "borderColor": "#FFFFFF",
            "padding": "40dp",
            "items": [
              {
                "type": "Text",
                "text": "📝 Facilidad de Uso",
                "color": "white",
                "fontSize": "48dp",
                "fontWeight": "bold",
                "textAlign": "center",
                "paddingBottom": "20dp"
              },
              {
                "type": "Text",
                "text": "${payload.documentData.title}",
                "color": "#FFD166",
                "fontSize": "30dp",
                "textAlign": "center",
                "paddingBottom": "30dp",
                "style": "questionStyle"
              },
              {
                "type": "Container",
                "direction": "column",
                "width": "100%",
                "items": [
                  {
                    "type": "TouchWrapper",
                    "onPress": {
                      "type": "SendEvent",
                      "arguments": ["cuestionarioUso","facil"]
                    },
                    "item": {
                      "type": "Container",
                      "direction": "row",
                      "alignItems": "center",
                      "padding": "15dp",
                      "marginBottom": "15dp",
                      "backgroundColor": "rgba(76, 175, 80, 0.3)",
                      "borderWidth": "2dp",
                      "borderColor": "#4CAF50",
                      "borderRadius": "10dp",
                      "items": [
                        {
                          "type": "Text",
                          "text": "😊",
                          "fontSize": "48dp",
                          "paddingRight": "20dp"
                        },
                        {
                          "type": "Text",
                          "text": "Creo que FÁCIL",
                          "color": "white",
                          "fontSize": "48dp",
                          "fontWeight": "bold"
                        }
                      ]
                    }
                  },
                  {
                    "type": "TouchWrapper",
                    "onPress": {
                      "type": "SendEvent",
                      "arguments": ["cuestionarioUso","dificil"]
                    },
                    "item": {
                      "type": "Container",
                      "direction": "row",
                      "alignItems": "center",
                      "padding": "15dp",
                      "backgroundColor": "rgba(244, 67, 54, 0.3)",
                      "borderWidth": "2dp",
                      "borderColor": "#F44336",
                      "borderRadius": "10dp",
                      "items": [
                        {
                          "type": "Text",
                          "text": "😣",
                          "fontSize": "48dp",
                          "paddingRight": "20dp"
                        },
                        {
                          "type": "Text",
                          "text": "Creo que DIFÍCIL",
                          "color": "white",
                          "fontSize": "48dp",
                          "fontWeight": "bold"
                        }
                      ]
                    }
                  }
                ]
              },
              {
                "type": "Text",
                "text": "ℹ️ Selecciona una opción tocándola",
                "color": "rgba(255,255,255,0.7)",
                "fontSize": "30dp",
                "paddingTop": "30dp",
                "fontStyle": "italic",
                "textAlign": "center"
              }
            ]
          }
        ]
      }
    ]
  },
  "styles": {
    "questionStyle": {
      "fontFamily": "Amazon Ember",
      "textAlign": "center",
      "fontWeight": "bold"
    }
  }
}
module.exports = { CuestionarioUso };