const Calendario = {
    type: "APL",
    version: "1.8",
    mainTemplate: {
        parameters: ["payload"],
        items: [
            {
                type: "Container",
                direction: "column",
                width: "100%",
                padding: 20,
                items: [
                    // Botón "Atrás"
                    {
                        type: "Container",
                        width: "100%",
                        alignItems: "start",
                        items: [
                            {
                                type: "TouchWrapper",
                                onPress: {
                                    type: "SendEvent",
                                    arguments: ["volverDeCalendario"]
                                },
                                item: {
                                    type: "Text",
                                    fontFamily: "Amazon Ember Display",
                                    text: "← Atrás",
                                    color: "white",
                                    textDecoration: "underline",
                                    fontSize: "26dp",
                                    fontWeight: "500",
                                    paddingBottom: "10dp"
                                }
                            }
                        ]
                    },

                    // Contenido centrado: Título y calendario
                    {
                        type: "Container",
                        direction: "column",
                        width: "100%",
                        alignItems: "center",
                        items: [
                            {
                                type: "Text",
                                text: "Calendario semanal",
                                fontFamily: "Amazon Ember Display",
                                color: "pink",
                                fontSize: "32dp",
                                fontWeight: "bold",
                                textAlign: "center",
                                paddingBottom: "30dp"
                            },

                            // Fila 1: Lunes a Jueves
                            {
                                type: "Container",
                                direction: "row",
                                width: "100%",
                                spacing: 6,
                                justifyContent: "spaceEvenly",
                                data: "${payload.documentData.calendarioFila1}",
                                item: {
                                    type: "Container",
                                    direction: "column",
                                    width: "23%",
                                    spacing: 6,
                                    alignItems: "center",
                                    items: [
                                        {
                                            type: "Text",
                                            text: "${data.dia}",
                                            fontFamily: "Amazon Ember Display",
                                            color: "powderblue",
                                            fontWeight: "bold",
                                            fontSize: "26dp",
                                            textAlign: "center",
                                            wrap: true
                                        },
                                        {
                                            type: "Text",
                                            when: "${data.tareas.length == 0}",
                                            text: "Sin tareas",
                                            textAlign: "center",
                                            fontFamily: "Amazon Ember Display",
                                            fontSize: "20dp",
                                            color: "gray"
                                        },
                                        {
                                            type: "Container",
                                            direction: "column",
                                            when: "${data.tareas.length > 0}",
                                            spacing: 12,                     // Más espacio entre tareas
                                            data: "${data.tareas}",
                                            item: {
                                                type: "Container",           // Cada tarea en su propio contenedor
                                                paddingBottom: "8dp",         // Espacio extra inferior
                                                items: [
                                                    {
                                                        type: "Text",
                                                        fontFamily: "Amazon Ember Display",
                                                        text: "${data}",
                                                        fontSize: "20dp",
                                                        wrap: true,
                                                        textAlign: "center"
                                                    }
                                                ]
                                            }
                                        }

                                    ]
                                }
                            },

                            // Espacio entre filas
                            {
                                type: "Container",
                                height: "80dp"
                            },

                            // Fila 2: Viernes a Domingo + avatar
                            {
                                type: "Container",
                                direction: "row",
                                width: "100%",
                                spacing: 6,
                                justifyContent: "spaceEvenly",
                                items: [
                                    {
                                        type: "Container",
                                        direction: "row",
                                        spacing: 6,
                                        data: "${payload.documentData.calendarioFila2}",
                                        item: {
                                            type: "Container",
                                            direction: "column",
                                            width: "23%",
                                            spacing: 6,
                                            alignItems: "center",
                                            items: [
                                                {
                                                    type: "Text",
                                                    text: "${data.dia}",
                                                    color: "powderblue",
                                                    fontWeight: "bold",
                                                    fontFamily: "Amazon Ember Display",
                                                    fontSize: "26dp",
                                                    textAlign: "center",
                                                    wrap: true
                                                },
                                                {
                                                    type: "Text",
                                                    when: "${data.tareas.length == 0}",
                                                    text: "Sin tareas",
                                                    textAlign: "center",
                                                    fontSize: "20dp",
                                                    fontFamily: "Amazon Ember Display",
                                                    color: "gray"
                                                },
                                                {
                                                    type: "Container",
                                                    direction: "column",
                                                    when: "${data.tareas.length > 0}",
                                                    spacing: 4,
                                                    data: "${data.tareas}",
                                                    item: {
                                                        type: "Text",
                                                        text: "${data}",
                                                        fontFamily: "Amazon Ember Display",
                                                        fontSize: "20dp",
                                                        wrap: true,
                                                        textAlign: "center"
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    // Columna extra con el avatar
                                    {
                                        type: "Video",
                                        width: "30vw",
                                        height: "30vh",
                                        autoplay: true,
                                        audioTrack: "none",
                                        source: "${payload.documentData.avatarUrl}"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
};

module.exports = { Calendario };
