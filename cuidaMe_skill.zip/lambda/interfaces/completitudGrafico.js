const CompletitudGrafico = {
  "type": "APL",
  "version": "1.7",
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "paddingTop": "20dp",
        "paddingLeft": "24dp",
        "paddingRight": "24dp",
        "items": [
          {
            "type": "TouchWrapper",
            "onPress": {
              "type": "SendEvent",
              "arguments": ["volverDeCompletitudGrafico"]
            },
            "item": {
              "type": "Text",
              "fontFamily": "Amazon Ember Display",
              "text": "← Atrás",
              "color": "white",
              "textDecoration": "underline",
              "fontSize": "26dp",
              "fontWeight": "500"
            }
          },
          {
            "type": "Text",
            "text": "${payload.documentData.title}",
            "color": "pink",
            "fontFamily": "Amazon Ember Display",
            "style": "textStyleSecondary",
            "paddingTop": "10dp"
          },
          {
            "type": "Sequence",
            "scrollDirection": "vertical",
            "height": "30vh",
            "paddingTop": "20dp",
            "data": "${payload.documentData.tareas}",
            "items": [
              {
                "type": "Text",
                "text": "${data.diasActivos ? '✅ ' : ''}${data.nombre}: ${data.diasActivos}",
                "fontFamily": "Amazon Ember Display",
                "fontSize": "32dp",
                "color": "white",
                "paddingBottom": "6dp"
              }
            ]

          },
          {
            "type": "Container",
            "justifyContent": "flex-start",
            "direction": "row",
            "alignItems": "end",
            "height": "200dp",
            "items": [
              {
                "type": "Container",
                "direction": "column-reverse",
                "alignItems": "center",
                "height": "100%",
                "items": [
                  {
                    "type": "Frame",
                    "width": "40dp",
                    "height": "${(payload.documentData.numCompletadas / payload.documentData.total) * 100}dp",
                    "backgroundColor": "green",
                    "scale": "1 0",
                    "animateItem": {
                      "when": true,
                      "duration": 600,
                      "value": [
                        {
                          "property": "scale",
                          "to": "1 1",
                          "easing": "ease-in-out"
                        }
                      ]
                    }
                  },
                  {
                    "type": "Text",
                    "text": "Completadas : ${payload.documentData.numCompletadas}",
                    "fontFamily": "Amazon Ember Display",
                    "style": "textStyleSecondary",
                    "paddingTop": "10dp"
                  }
                ]
              },
            
              {
                "type": "Container",
                "direction": "column-reverse",
                "paddingLeft": "20dp",
                "alignItems": "center",
                "height": "100%",
                "items": [
                  {
                    "type": "Frame",
                    "width": "40dp",
                    "height": "${((payload.documentData.total - payload.documentData.numCompletadas) / payload.documentData.total) * 100}dp",
                    "backgroundColor": "red",
                    "scale": "1 0",
                    "animateItem": {
                      "when": true,
                      "duration": 600,
                      "value": [
                        {
                          "property": "scale",
                          "to": "1 1",
                          "easing": "ease-in-out"
                        }
                      ]
                    }
                  },
                  {
                    "type": "Text",
                    "text": "No completadas : ${(payload.documentData.total - payload.documentData.numCompletadas)}",
                    "fontFamily": "Amazon Ember Display",
                    "style": "textStyleSecondary",
                    "paddingTop": "10dp"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
};

module.exports = { CompletitudGrafico };