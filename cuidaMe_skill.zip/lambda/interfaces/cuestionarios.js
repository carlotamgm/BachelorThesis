const Cuestionarios = {
  type: "APL",
  version: "1.8",
  mainTemplate: {
    parameters: ["payload"],
    items: [
      {
        type: "Container",
        width: "100vw",
        height: "100vh",
        direction: "column",
        justifyContent: "start",
        alignItems: "center",
        paddingTop: "5vh",
        spacing: 30,
        items: [
          // Botón marcha atrás
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["volverDeResumen"]
            },
            item: {
              type: "Text",
              fontFamily: "Amazon Ember Display",
              text: "← Atrás",
              color: "white",
              textDecoration: "underline",
              fontSize: "26dp",
              fontWeight: "500"
            },
            paddingBottom: "6vh" // 👈 espacio vertical adicional
          },
          // Texto pregunta
          {
            type: "Text",
            text: " ¿Qué cuestionario deseas realizar? ",
            fontSize: "8vh",
            fontWeight: "bold",
            color: "pink",
            textAlign: "center",
            paddingBottom: "6vh"
          },

          // Botones cuestionarios
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["cuestionarioCognitivo"]
            },
            item: {
              type: "Text",
              text: "🧠 Cuestionario COGNITIVO",
              fontSize: "48dp",
              color: "white",
              wrap: true,
              textAlign: "center"
            },
            paddingBottom: "6vh" // 👈 espacio vertical adicional
          },
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["cuestionarioSatisfaccion"]
            },
            item: {
              type: "Text",
              text: "😊 Cuestionario de SATISFACCIÓN",
              fontSize: "48dp",
              color: "white",
              wrap: true,
              textAlign: "center"
            },
            paddingBottom: "6vh" // 👈 espacio vertical adicional
          },
          {
            type: "TouchWrapper",
            onPress: {
              type: "SendEvent",
              arguments: ["cuestionarioUso"]
            },
            item: {
              type: "Text",
              text: "💡 Cuestionario de HABILIDAD CON LA APP",
              fontSize: "48dp",
              color: "white",
              wrap: true,
              textAlign: "center"
            }
          }
        ]
      }
    ]
  }
};

module.exports = { Cuestionarios };
