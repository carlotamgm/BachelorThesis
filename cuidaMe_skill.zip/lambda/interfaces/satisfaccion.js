const Satisfaccion = {
  "type": "APL",
  "version": "1.9",
  "styles": {
    "textStylePrimary": {
      "fontSize": "24dp",
      "fontWeight": "bold",
      "color": "black"
    },
    "textStyleSecondary": {
      "fontSize": "18dp",
      "color": "#AAAAAA"
    }
  },
  "mainTemplate": {
    "parameters": ["payload"],
    "items": [
      {
        "type": "Container",
        "direction": "column",
        "width": "100vw",
        "height": "100vh",
        "items": [
          {
            "type": "TouchWrapper",
            "width": "20vw",
            "height": "6vh",
            "onPress": {
              "type": "SendEvent",
              "arguments": ["volverDeSatisfaccion"]
            },
            "item": {
              "type": "Text",
              "text": "← Atrás",
              "color": "white",
              "fontSize": "26dp",
              "fontWeight": "600",
              "textAlign": "center",
              "textAlignVertical": "center"
            }
          },
          {
            "type": "Text",
            "text": "Valoración: ${payload.documentData.valorTexto}",
            "style": "textStylePrimary",
            "fontSize": "28dp",
            "marginTop": "3vh",
            "textAlign": "center"
          },
          {
            "type": "Image",
            "source": "${payload.documentData.imagenPastel}",
            "width": "60vw",
            "height": "60vw",
            "alignSelf": "center",
            "marginTop": "3vh"
          },
          {
            "type": "Text",
            "text": "Puntuación: ${payload.documentData.numero}/10",
            "style": "textStyleSecondary",
            "marginTop": "2vh",
            "textAlign": "center"
          }
        ]
      }
    ]
  }
}


module.exports = { Satisfaccion };