const OrientacionEspacial = {
    type: "APL",
    version: "1.8",
    mainTemplate: {
        parameters: ["payload"],
        items: [
            {
                type: "Container",
                width: "100vw",
                height: "100vh",
                justifyContent: "center",
                alignItems: "center",
                items: [
                    {
                        type: "Container",
                        direction: "column",
                        width: "80%",
                        alignItems: "center",
                        spacing: 16,
                        items: [
                            {
                                type: "Text",
                                text: "🧠 Orientación Espacial",
                                fontSize: "8vh",
                                fontWeight: "bold",
                                color: "pink",
                                textAlign: "center",
                                paddingBottom: "20dp"
                            },
                            {
                                type: "Text",
                                text: "1. ¿En qué lugar estamos?",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "2. ¿En qué planta o sala?",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "3. ¿En qué pueblo o ciudad?",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "4. ¿En qué provincia?",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "Text",
                                text: "5. ¿En qué país o comunidad?",
                                fontSize: "30dp",
                                color: "white",
                                wrap: true,
                                textAlign: "center"
                            },
                            {
                                type: "TouchWrapper",
                                onPress: {
                                    type: "SendEvent",
                                    arguments: ["siguienteSeccion"]
                                },
                                item: {
                                    type: "Frame",
                                    backgroundColor: "powderblue",
                                    borderRadius: "12dp",
                                    paddingLeft: "32dp",
                                    paddingRight: "32dp",
                                    paddingTop: "16dp",
                                    paddingBottom: "16dp",
                                    item: {
                                        type: "Text",
                                        text: "SIGUIENTE SECCIÓN",
                                        fontSize: "40dp",
                                        fontWeight: "bold",
                                        color: "black",
                                        textAlign: "center"
                                    }
                                },
                                alignSelf: "center",
                                paddingTop: "20dp"
                            }
                        ]
                    }
                ]
            }
        ]
    }
};

module.exports = { OrientacionEspacial };
